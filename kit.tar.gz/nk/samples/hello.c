/* Nk 集成自检样本：同时覆盖常量、字符串、循环、分支、算术混合 */
#include <stdio.h>
#include <string.h>

const char *nk_secret_token = "NK_SECRET_TOKEN_12345";
static const unsigned int NK_MAGIC = 0x9E3779B9u;

static int mix(int a, int b) {
  return ((a ^ b) + (a << 3)) - (b >> 2);
}

int nk_calc(int x) {
  int s = 0;
  for (int i = 0; i < 16; i++) {
    s += mix(x + i, i * 7) ^ (int)NK_MAGIC;
    if ((s & 1) == 0) {
      s += 3;
    } else {
      s -= 5;
    }
  }
  return s;
}

int nk_check(const char *s) {
  if (s == NULL) return -1;
  return strcmp(s, nk_secret_token) == 0 ? 0 : 1;
}

int main(void) {
  printf("%s %d\n", nk_secret_token, nk_calc(42));
  return nk_check(nk_secret_token);
}
