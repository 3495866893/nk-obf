#!/usr/bin/env bash
# =============================================================================
# pc-linux-build.sh —— 在电脑（Linux / WSL Ubuntu）上直接编工程，带 Nk 混淆
# -----------------------------------------------------------------------------
# 不需要重编 NDK 的 clang：直接用系统装的 LLVM 21 clang（动态链接 libLLVM，
# 天生支持 -fpass-plugin），配 NDK 的 sysroot 交叉到 Android。
#
# 用法：
#   ./pc-linux-build.sh --src ~/proj/src --out ~/out/app \
#        --sysroot ~/android-ndk-r29/toolchains/llvm/prebuilt/linux-x86_64/sysroot \
#        --preset max --extra "-lEGL -lGLESv2 -lGLESv3 -landroid -llog"
#
#   常用参数：
#     --kind exe|so      产物类型（默认 exe）
#     --abi arm64-v8a|armeabi-v7a|x86_64   默认 arm64-v8a
#     --api 26           默认 26
#     --preset low|mid|high|max            默认 max
#     --sysroot PATH     目标 sysroot（NDK 的 .../sysroot）
#     --extra "..."      追加链接参数（-lEGL 等）
#     --desktop          先在本机（x86_64 Linux）编一份自测，确认混淆生效
#
# 依赖（Ubuntu/WSL）：
#   sudo apt install -y clang-21 llvm-21-dev cmake ninja-build libc++-21-dev
#   （clang-21 来自 apt.llvm.org；见 oneclick/README.txt）
# =============================================================================
set -euo pipefail

HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
KIT=$(cd -- "$HERE/.." && pwd)          # .../nk
PRE=$(cd -- "$KIT/.." && pwd)           # .../prebuilt/linux-arm64（若在 NDK 内）

SRC=""; OUT=""; SYSROOT="${SYSROOT:-}"; API=26; ABI=arm64-v8a
PRESET=max; KIND=exe; EXTRA=""; DESKTOP=0
LIB="$KIT/lib/libNk.so"

log() { printf '[pc-build] %s\n' "$*"; }
die() { printf '[pc-build] 错误: %s\n' "$*" >&2; exit 1; }
usage() { sed -n '2,30p' "$0" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
  case "$1" in
    --src) SRC="$2"; shift 2 ;;
    --out) OUT="$2"; shift 2 ;;
    --sysroot) SYSROOT="$2"; shift 2 ;;
    --api) API="$2"; shift 2 ;;
    --abi) ABI="$2"; shift 2 ;;
    --preset) PRESET="$2"; shift 2 ;;
    --kind) KIND="$2"; shift 2 ;;
    --extra) EXTRA="$2"; shift 2 ;;
    --desktop) DESKTOP=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "未知参数: $1" ;;
  esac
done

case "$ABI" in
  arm64-v8a)   TRIPLE=aarch64-linux-android ;;
  armeabi-v7a) TRIPLE=armv7a-linux-androideabi ;;
  x86_64)      TRIPLE=x86_64-linux-android ;;
  x86)         TRIPLE=i686-linux-android ;;
  *) die "不支持的 ABI: $ABI" ;;
esac

# --- 1. 找 clang 21 / llvm-config 21 --------------------------------------
CLANG=""; LLVMCONF=""
for c in clang-21 clang; do
  command -v "$c" >/dev/null 2>&1 && { CLANG=$(command -v "$c"); break; }
done
for c in llvm-config-21 llvm-config; do
  command -v "$c" >/dev/null 2>&1 && { LLVMCONF=$(command -v "$c"); break; }
done
[ -n "$CLANG" ] || die "没找到 clang-21。Ubuntu/WSL 安装：
  wget -qO- https://apt.llvm.org/llvm-snapshot.gpg.key | sudo tee /etc/apt/trusted.gpg.d/llvm.asc >/dev/null
  echo 'deb http://apt.llvm.org/jammy/ llvm-toolchain-jammy-21 main' | sudo tee /etc/apt/sources.list.d/llvm21.list
  sudo apt update && sudo apt install -y clang-21 llvm-21-dev cmake ninja-build libc++-21-dev"
[ -n "$LLVMCONF" ] || die "没找到 llvm-config-21（llvm-21-dev 包）"
log "clang : $CLANG"
log "llvm  : $("$LLVMCONF" --version)"

# --- 2. 编插件（如果还没有）-----------------------------------------------
if [ ! -f "$LIB" ]; then
  command -v cmake >/dev/null || die "缺 cmake"
  command -v ninja >/dev/null || die "缺 ninja"
  log "编译 nk 插件（首次约 1–3 分钟）"
  cmake -S "$KIT/src" -B "$KIT/.build/plugin" -G Ninja \
        -DCMAKE_BUILD_TYPE=Release \
        -DLLVM_DIR="$("$LLVMCONF" --cmakedir)" >/dev/null
  cmake --build "$KIT/.build/plugin" --target Nk --parallel "$(nproc)"
  SO=$(find "$KIT/.build/plugin" -name libNk.so -type f | head -1)
  [ -n "$SO" ] || die "插件编译失败"
  mkdir -p "$KIT/lib"; cp -f "$SO" "$LIB"; chmod 755 "$LIB"
fi
log "插件 : $LIB ($(du -h "$LIB" | cut -f1))"

# --- 3. 桌面自测（可选，先在本机验证混淆链路）-----------------------------
if [ "$DESKTOP" = "1" ]; then
  command -v "$CLANG" >/dev/null && log "桌面自测：编一个 hello 并跑"
  T=$(mktemp -d)
  printf '#include <stdio.h>\nconst char*s="NK_PC_TEST";\nint main(){printf("%%s\\n",s);return 0;}\n' > "$T/h.c"
  NK_CONFIG="$KIT/config/presets/max-all.toml" NK=1 NK_PRESET="$PRESET" \
    "$CLANG" -fpass-plugin="$LIB" -O2 "$T/h.c" -o "$T/h"
  "$T/h" >/dev/null && log "✔ 桌面自测通过（插件可加载、产物可运行）"
  strings -a "$T/h" | grep -q NK_PC_TEST && log "⚠ 明文仍在（可能 pass 未作用于 -O2 之外的代码）" || log "✔ 明文字符串已被加密"
  rm -rf "$T"
fi

[ -n "$SRC" ] || { log "没有 --src，只完成插件构建"; exit 0; }
[ -n "$OUT" ] || die "缺少 --out"
[ -d "$SRC" ] || die "源码目录不存在: $SRC"

# --- 4. sysroot ------------------------------------------------------------
if [ -z "$SYSROOT" ]; then
  SYSROOT="$PRE/sysroot"        # kit 在 NDK 里时的默认位置
fi
if [ ! -d "$SYSROOT" ]; then
  die "找不到 sysroot（--sysroot 指定）。从 NDK 包里抠出来即可：
  tar -xzf ndk-arm64-26-nk.tar.gz --wildcards '*/toolchains/llvm/prebuilt/*/sysroot/*'
  或用官方 NDK：\$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot"
fi
log "sysroot: $SYSROOT"

# --- 5. 交叉编译 ----------------------------------------------------------
TARGET="$TRIPLE$API"
CFLAGS_COMMON=(-fPIC -ffunction-sections -fdata-sections -fno-ident)
LDFLAGS_COMMON=(-Wl,--gc-sections -Wl,--exclude-libs,ALL -Wl,-z,relro -Wl,-z,now)

if [ "$KIND" = "so" ]; then
  MODE=(-shared)
else
  MODE=()
fi

SOURCES=$(find "$SRC" -maxdepth 1 \( -name '*.c' -o -name '*.cpp' -o -name '*.cc' \) | sort)
[ -n "$SOURCES" ] || die "$SRC 下没有 .c/.cpp"
log "源文件 $(echo "$SOURCES" | wc -l) 个 → $OUT"

mkdir -p "$(dirname "$OUT")"
# shellcheck disable=SC2086
NK_CONFIG="$KIT/config/presets/max-all.toml" NK=1 NK_PRESET="$PRESET" \
"$CLANG" --target="$TARGET" --sysroot="$SYSROOT" \
         -fpass-plugin="$LIB" \
         "${MODE[@]}" -O2 "${CFLAGS_COMMON[@]}" \
         -o "$OUT" $SOURCES \
         "${LDFLAGS_COMMON[@]}" ${EXTRA}

log "✔ 产物: $OUT ($(du -h "$OUT" | cut -f1))"
if command -v readelf >/dev/null; then
  readelf -h "$OUT" | awk -F: '/Machine|Type/{gsub(/^ +/,"",$2);print "   "$1":"$2}'
fi
cat <<EOF

下一步：
  * 可执行文件：adb push "$OUT" /data/local/tmp/ && adb shell chmod 755 /data/local/tmp/$(basename "$OUT")
  * .so：放进工程 libs/$ABI/ 或 AIDE 的预编译目录，由 AIDE 打包 APK
  * 想确认混淆：strings -a "$OUT" | grep 你的明文关键字   → 应该搜不到
EOF
