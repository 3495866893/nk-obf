#!/system/bin/sh
# =============================================================================
# install.sh —— 设备端一键安装 / 卸载 Nk for AIDE
# -----------------------------------------------------------------------------
# 用法（AIDE 内置终端 / Termux（需能访问该目录，通常要 root）/ adb shell su）：
#
#   sh install.sh                 # 自动找 AIDE 的 NDK 目录并安装（无 dropin 时为安全模式）
#   sh install.sh --dropin /sdcard/nk-dropin.zip --jni /sdcard/你的工程/jni
#   sh install.sh --revert --jni /sdcard/你的工程/jni     # 卸载（还原 mk、恢复原 clang）
#   sh install.sh --check         # 只做自检
#
# 它做这些事（全部幂等，改前自动 .bak）：
#   1. 找到 AIDE 的 NDK（toolchains/llvm/prebuilt/*）
#   2. 修复解包丢失的 bin/clang++ 软链接、权限位
#   3. 若给了 --dropin：装入 clang-21 / libNk.so / .plugin-capable
#   4. 给工程 jni/Android.mk 插入 Nk 段、给 Application.mk 导出环境变量
#      （没有插件时自动写成“安全模式”：NK=0，工程照常能编）
#   5. 打印自检结论
# =============================================================================
set -u

BEGIN_MK="# == NK-BEGIN == (install.sh 自动生成，--revert 可移除)"
END_MK="# == NK-END =="
BEGIN_APP="# == NK-APP-BEGIN =="
END_APP="# == NK-APP-END =="

DROPIN=""
NDK_DIR=""
JNI_DIR=""
MODE=install

while [ $# -gt 0 ]; do
  case "$1" in
    --dropin) DROPIN="$2"; shift 2 ;;
    --ndk)    NDK_DIR="$2"; shift 2 ;;
    --jni)    JNI_DIR="$2"; shift 2 ;;
    --check)  MODE=check; shift ;;
    --revert) MODE=revert; shift ;;
    -h|--help) sed -n '2,30p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "未知参数: $1（--help）" >&2; exit 2 ;;
  esac
done

say() { printf '%s\n' "$*"; }
ok()  { printf '  [OK]   %s\n' "$*"; }
bad() { printf '  [缺]   %s\n' "$*"; }
warn(){ printf '  [注意] %s\n' "$*"; }
die() { printf '错误: %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------------------
# 定位 NDK
# ---------------------------------------------------------------------------
find_ndk() {
  [ -n "$NDK_DIR" ] && { echo "$NDK_DIR"; return; }
  for pat in \
    /data/user/0/ru.factorcode.aidepro/no_backup/ndksupport-*/android-ndk-aide \
    /data/data/ru.factorcode.aidepro/no_backup/ndksupport-*/android-ndk-aide \
    /sdcard/android-ndk-aide \
    /storage/emulated/0/android-ndk-aide \
    /storage/emulated/0/Android/android-ndk-aide \
    /data/local/tmp/android-ndk-aide \
    "$PWD/android-ndk-aide" ; do
    for x in $pat; do
      [ -d "$x/toolchains/llvm/prebuilt" ] && { echo "$x"; return; }
    done
  done
}

D=$(find_ndk)
[ -n "$D" ] || die "找不到 NDK 目录，用 --ndk <路径> 指定（例：--ndk /data/user/0/ru.factorcode.aidepro/no_backup/ndksupport-XXXX/android-ndk-aide）"
P=""
for x in "$D"/toolchains/llvm/prebuilt/*; do [ -d "$x" ] && { P="$x"; break; }; done
[ -n "$P" ] || die "$D 不是完整 NDK（缺 toolchains/llvm/prebuilt）"
E="$P/nk"

say "NDK : $D"
say "PRE : $P"

# ---------------------------------------------------------------------------
PATHFIX 基础修复（clang++ 软链接 / 权限）
# ---------------------------------------------------------------------------
fix_basics() {
  if [ ! -e "$P/bin/clang++" ] && [ -e "$P/bin/clang" ]; then
    ( cd "$P/bin" && ln -s clang clang++ ) 2>/dev/null && ok "补建 bin/clang++ -> clang" \
      || bad "补建 bin/clang++ 失败（权限不够？）"
  fi
  [ -f "$P/bin/clang" ] && chmod 755 "$P/bin/clang" 2>/dev/null
  [ -f "$P/bin/clang-21" ] && chmod 700 "$P/bin/clang-21" 2>/dev/null
  if [ -d "$E/bin" ]; then
    chmod 755 "$E"/bin/*.sh 2>/dev/null
    chmod 755 "$E/bin/nk-clang" 2>/dev/null
  fi
}

# ---------------------------------------------------------------------------
# dropin 安装
# ---------------------------------------------------------------------------
install_dropin() {
  F="$1"
  [ -f "$F" ] || { bad "dropin 文件不存在: $F"; return 1; }
  T=$(mktemp -d 2>/dev/null || echo "/data/local/tmp/nk-dropin-$$")
  mkdir -p "$T" || return 1
  case "$F" in
    *.zip) unzip -oq "$F" -d "$T" 2>/dev/null || { bad "解压失败（缺 unzip？）"; return 1; } ;;
    *)     tar -xzf "$F" -C "$T" 2>/dev/null || { bad "解压失败"; return 1; } ;;
  esac

  NEWCLANG=$(find "$T" -name 'clang-21' -type f 2>/dev/null | head -1)
  NEWSO=$(find "$T" -name 'libNk.so' -type f 2>/dev/null | head -1)

  if [ -n "$NEWCLANG" ]; then
    [ -f "$P/bin/clang-21" ] && [ ! -f "$P/bin/clang-21.orig.bak" ] && \
      cp -f "$P/bin/clang-21" "$P/bin/clang-21.orig.bak" && ok "已备份原 clang-21 -> clang-21.orig.bak"
    cp -f "$NEWCLANG" "$P/bin/clang-21" && chmod 700 "$P/bin/clang-21" && ok "已装入新 clang-21"
  else
    warn "dropin 里没有 clang-21（只装插件？）"
  fi

  if [ -n "$NEWSO" ]; then
    mkdir -p "$E/lib"
    cp -f "$NEWSO" "$E/lib/libNk.so" && chmod 755 "$E/lib/libNk.so" && ok "已装入 libNk.so"
  else
    bad "dropin 里没有 libNk.so"
  fi

  if [ -n "$NEWCLANG" ] && [ -n "$NEWSO" ]; then
    date > "$E/lib/.plugin-capable" 2>/dev/null && ok "已写 .plugin-capable"
  fi
  rm -rf "$T" 2>/dev/null
}

# ---------------------------------------------------------------------------
# 工程接入（Android.mk / Application.mk）
# ---------------------------------------------------------------------------
have_sed() { command -v sed >/dev/null 2>&1; }

strip_block() { # file begin end
  [ -f "$1" ] || return 0
  have_sed || return 0
  sed "/$(echo "$2" | sed 's/[\/&]/\\&/g')/,/$(echo "$3" | sed 's/[\/&]/\\&/g')/d" "$1" > "$1.tmp" && mv "$1.tmp" "$1"
}

patch_jni() {
  J="$1"
  MK="$J/Android.mk"
  APP="$J/Application.mk"
  [ -f "$MK" ] || { warn "没有 $MK，跳过 mk 接入"; return 0; }

  PLUGIN_OK=0
  [ -f "$E/lib/libNk.so" ] && [ -e "$E/lib/.plugin-capable" ] && PLUGIN_OK=1

  cp -f "$MK" "$MK.bak" 2>/dev/null
  strip_block "$MK" "$BEGIN_MK" "$END_MK"

  # 插到第一条 include $(BUILD_ 之前；没有就追加到末尾
  TMP="$MK.tmp"
  awk -v beg="$BEGIN_MK" -v end="$END_MK" -v lib="$E/lib/libNk.so" -v ok="$PLUGIN_OK" '
    function emit(   s) {
      s = beg "\n"
      s = s "NK_LIB := " lib "\n"
      s = s "ifeq ($(NK),1)\n"
      s = s "  NK_FLAG := -fpass-plugin=$(NK_LIB)\n"
      s = s "else\n"
      s = s "  NK_FLAG :=\n"
      s = s "endif\n"
      s = s "LOCAL_CFLAGS   += $(NK_FLAG)\n"
      s = s "LOCAL_CPPFLAGS += $(NK_FLAG)\n"
      s = s end
      print s
    }
    !done && /^[ \t]*include[ \t]+\$\(BUILD_/ { emit(); done=1 }
    { print }
    END { if (!done) emit() }
  ' "$MK" > "$TMP" && mv "$TMP" "$MK" && ok "已写入 $MK"

  if [ -f "$APP" ]; then
    APP_EXISTED=1
    cp -f "$APP" "$APP.bak" 2>/dev/null
    strip_block "$APP" "$BEGIN_APP" "$END_APP"
  else
    APP_EXISTED=0
    printf 'APP_ABI := arm64-v8a\nAPP_PLATFORM := android-26\nAPP_OPTIM := release\n\n' > "$APP"
  fi
  cat >> "$APP" <<EOF
$BEGIN_APP
# 由 nk/oneclick/install.sh 写入；插件未安装时自动关闭，保证工程可编
export NK        := $PLUGIN_OK
export NK_PRESET := max
export NK_CONFIG := $E/config/presets/max-all.toml
$END_APP
EOF
  if [ "$APP_EXISTED" = "1" ]; then
    ok "已写入 $APP（NK=$PLUGIN_OK）"
  else
    ok "已新建 $APP（NK=$PLUGIN_OK，APP_ABI=arm64-v8a）"
  fi

  if [ "$PLUGIN_OK" = "0" ]; then
    warn "插件还不完整 → 本次写成安全模式（NK=0，先保证能编）"
    warn "把电脑上生成的 nk-dropin.zip 传上来，再跑一次本脚本即可开启混淆"
  fi
}

revert_jni() {
  J="$1"
  for f in "$J/Android.mk" "$J/Application.mk"; do
    [ -f "$f" ] || continue
    case "$f" in
      *Android.mk)    strip_block "$f" "$BEGIN_MK" "$END_MK" ;;
      *Application.mk) strip_block "$f" "$BEGIN_APP" "$END_APP" ;;
    esac
    [ -f "$f.bak" ] && cp -f "$f.bak" "$f"
    ok "已还原 $f"
  done
  if [ -f "$P/bin/clang-21.orig.bak" ]; then
    cp -f "$P/bin/clang-21.orig.bak" "$P/bin/clang-21" && chmod 700 "$P/bin/clang-21"
    ok "已恢复原 clang-21"
  fi
  [ -f "$E/lib/.plugin-capable" ] && rm -f "$E/lib/.plugin-capable" && ok "已移除 .plugin-capable"
}

# ---------------------------------------------------------------------------
# 自检
# ---------------------------------------------------------------------------
selfcheck() {
  say ""
  say "自检"
  [ -f "$P/bin/clang-21" ] && ok "clang-21 存在" || bad "clang-21 缺失"
  [ -x "$P/bin/clang" ] && ok "bin/clang 可执行（$(head -1 "$P/bin/clang" 2>/dev/null | tr -d '\r')）" \
                        || bad "bin/clang 不可执行"
  [ -e "$P/bin/clang++" ] && ok "bin/clang++ 存在" || bad "bin/clang++ 缺失（C++ 工程必需）"
  [ -d "$P/lib/clang/21/include" ] && ok "内建头文件目录存在" || bad "lib/clang/21/include 缺失"
  [ -d "$E" ] && ok "nk kit 存在" || bad "nk kit 缺失（不是 Nk 版 NDK？）"
  if [ -f "$E/lib/libNk.so" ]; then
    ok "libNk.so $(ls -l "$E/lib/libNk.so" | awk '{print $5}') 字节"
  else
    bad "libNk.so 缺失（电脑生成 dropin 后 --dropin 装入）"
  fi
  [ -e "$E/lib/.plugin-capable" ] && ok ".plugin-capable 存在" || bad ".plugin-capable 缺失"
  say ""
  if [ -f "$E/lib/libNk.so" ] && [ -e "$E/lib/.plugin-capable" ]; then
    say "✅ 已就绪：ndk-build clean && ndk-build，混淆（max-all）自动生效"
  else
    say "⚠ 还差二进制。下一步（电脑上，一条命令）："
    say "    sh oneclick/pc-build-dropin.sh        # 产出 nk-dropin.zip"
    say "  然后把 zip 传到手机，执行："
    say "    sh install.sh --dropin /sdcard/nk-dropin.zip --jni <工程>/jni"
  fi
}

# ---------------------------------------------------------------------------
case "$MODE" in
  check)
    selfcheck
    exit 0
    ;;
  revert)
    fix_basics
    [ -n "$JNI_DIR" ] || die "--revert 需要 --jni <工程/jni 目录>"
    revert_jni "$JNI_DIR"
    exit 0
    ;;
esac

# install
[ -d "$E" ] || die "这不是 Nk 版 NDK（缺 $E）。请先用 Nk 版 NDK 包替换 AIDE 的 NDK。"
fix_basics
[ -n "$DROPIN" ] && install_dropin "$DROPIN"

J="$JNI_DIR"
if [ -z "$J" ]; then
  # 从当前目录向上找 jni/Android.mk
  d=$(pwd)
  while [ "$d" != "/" ]; do
    [ -f "$d/jni/Android.mk" ] && { J="$d/jni"; break; }
    [ -f "$d/Android.mk" ] && { J="$d"; break; }
    d=$(dirname "$d")
  done
fi
if [ -n "$J" ]; then
  patch_jni "$J"
else
  warn "没找到 jni/Android.mk（用 --jni 指定）；只做了 NDK 侧安装"
fi

selfcheck
