#!/usr/bin/env bash
# =============================================================================
# pc-build-dropin.sh —— 在电脑（Linux x86_64 / macOS 上装好 GNU 工具亦可）产出一个
#                      「手机端一键安装」的 dropin 包：nk-dropin.tar.gz
# -----------------------------------------------------------------------------
# 产出内容：
#   bin/clang-21        可加载 LLVM pass plugin 的 clang（aarch64-linux-android）
#   lib/libNk.so     nk 插件
#   lib/.plugin-capable 能力标记
#   oneclick/           手机端安装脚本
#
# 用法：
#   bash oneclick/pc-build-dropin.sh                # 自动下载官方 NDK r29 编译
#   NDK=/opt/android-ndk-r29 bash oneclick/pc-build-dropin.sh
#   WORK=~/nk-work JOBS=8 bash oneclick/pc-build-dropin.sh
#
# 依赖：curl（或 wget）、unzip、git、cmake>=3.28、ninja、python3，
#       磁盘 ≥ 40 GB，内存 ≥ 16 GB（8 核约 1–2 小时）。
# 没电脑？把 kit/nk/ci/build-nk-ndk.yml 放进 GitHub 仓库跑 Actions 也行。
# =============================================================================
set -euo pipefail

HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)      # .../nk/oneclick
NK_DIR=$(cd -- "$HERE/.." && pwd)                          # .../nk
KIT_PARENT=$(cd -- "$NK_DIR/.." && pwd)                    # kit 目录（含 clang 包装器）
WORK=${WORK:-$PWD/nk-work}
JOBS=${JOBS:-$( (command -v nproc >/dev/null && nproc) || echo 4 )}
NDK_VER=${NDK_VER:-r29}
DOWNLOAD_NDK=${DOWNLOAD_NDK:-1}

log()  { printf '[pc-build] %s\n' "$*"; }
die()  { printf '[pc-build] 错误: %s\n' "$*" >&2; exit 1; }

for t in curl unzip git cmake ninja; do
  command -v "$t" >/dev/null || die "缺少 $t（apt install curl unzip git cmake ninja-build）"
done

mkdir -p "$WORK"
cd "$WORK"

# --- 1. 官方 NDK（只需要 host 工具链 + 目标 sysroot）-------------------------
if [ -z "${NDK:-}" ]; then
  NDK_DIR="$WORK/android-ndk-$NDK_VER"
  if [ ! -d "$NDK_DIR" ]; then
    [ "$DOWNLOAD_NDK" = "1" ] || die "NDK 目录不存在且 DOWNLOAD_NDK=0"
    log "下载官方 NDK $NDK_VER（约 700 MB）"
    curl -fL --retry 3 -o "ndk-$NDK_VER.zip" \
      "https://dl.google.com/android/repository/android-ndk-$NDK_VER-linux.zip"
    unzip -q -o "ndk-$NDK_VER.zip"
    [ -d "$NDK_DIR" ] || die "解压后找不到 $NDK_DIR"
  fi
  NDK="$NDK_DIR"
fi
[ -d "$NDK/toolchains/llvm/prebuilt/linux-x86_64" ] || die "$NDK 缺 linux-x86_64 prebuilt（需要官方完整 NDK）"
log "NDK: $NDK"

PRE="$NDK/toolchains/llvm/prebuilt/linux-arm64"
mkdir -p "$PRE/bin"

# --- 2. 把 kit 放到目标 prebuilt -------------------------------------------
rm -rf "$PRE/nk"
cp -r "$NK_DIR" "$PRE/nk"
if [ -f "$KIT_PARENT/clang" ]; then
  rm -f "$PRE/bin/clang"
  cp "$KIT_PARENT/clang" "$PRE/bin/clang"
  chmod 755 "$PRE/bin/clang"
fi

# --- 3. 编 clang + 插件（只输出 clang-21 与 libNk.so）-------------------
OUT="$WORK/dropin-out"
mkdir -p "$OUT"
log "开始编译（预计很久，日志见 $WORK/build.log）"
"$PRE/nk/bin/build-clang.sh" --ndk "$NDK" --work "$WORK/llvm-work" \
    --jobs "$JOBS" --out-dir "$OUT" 2>&1 | tee "$WORK/build.log"

[ -f "$OUT/clang-21" ]   || die "构建失败：没有 clang-21（看 $WORK/build.log）"
[ -f "$OUT/libNk.so" ] || die "构建失败：没有 libNk.so"

# --- 4. 打包 dropin --------------------------------------------------------
STAGE="$WORK/dropin-stage"
rm -rf "$STAGE"; mkdir -p "$STAGE/bin" "$STAGE/lib" "$STAGE/oneclick"
cp "$OUT/clang-21"   "$STAGE/bin/clang-21"
cp "$OUT/libNk.so" "$STAGE/lib/libNk.so"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$STAGE/lib/.plugin-capable"
cp "$HERE/install.sh" "$STAGE/oneclick/" 2>/dev/null || true
printf 'Nk dropin for Android NDK %s\nclang-21 + libNk.so + marker\n' "$NDK_VER" \
  > "$STAGE/INFO.txt"

ZIP="$WORK/nk-dropin.tar.gz"
( cd "$STAGE" && tar -czf "$ZIP" . )
log "完成：$ZIP（$(du -h "$ZIP" | cut -f1)）"
cat <<EOF

下一步（手机端一条命令，AIDE 终端 / Termux+su / adb shell su）：
  sh oneclick/install.sh --dropin /sdcard/nk-dropin.tar.gz --jni /sdcard/你的工程/jni

或者手动放三个文件：
  $PRE/bin/clang-21
  $PRE/nk/lib/libNk.so
  $PRE/nk/lib/.plugin-capable
EOF
