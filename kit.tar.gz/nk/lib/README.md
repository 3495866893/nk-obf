# lib/ —— 插件产物目录

`libNk.so` 必须由本机/构建机**现场编译**，因为：

- LLVM pass plugin 只能加载到**与编译时完全相同的 LLVM 版本、同一构建配置**的 clang 里；
- 本 NDK 的 `bin/clang-21` 是 `21.0.0 (based on r563880c)` 的 Android 定制版，与任何第三方
  预编译插件都不匹配；
- 而且它静态链接、没有 `.dynsym`，插件根本无从解析 LLVM 符号。

## 怎么产出

```bash
# 一步到位：重编 clang（导出 LLVM 符号）+ 编译插件 + 写入能力标记
<ndk>/toolchains/llvm/prebuilt/linux-arm64/nk/bin/build-clang.sh

# 只重编插件（clang 已经重编过，或你自行提供了匹配的 LLVM 21 构建树）
<ndk>/.../nk/bin/build-plugin.sh --llvm-dir /path/to/llvm-21/lib/cmake/llvm
```

## 文件说明

| 文件 | 说明 |
| --- | --- |
| `libNk.so` | 插件本体，`-fpass-plugin=` 的目标 |
| `.plugin-capable` | 能力标记，由 `install-plugin.sh` 在校验通过后写入；`bin/clang` 包装器凭它决定是否注入 |

删除 `.plugin-capable` 即可让包装器回到「完全透传」状态（等价关闭混淆）。
