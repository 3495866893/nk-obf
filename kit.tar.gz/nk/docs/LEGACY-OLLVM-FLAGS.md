# 混淆开关速查（Nk / OLLVM-Next，Android.mk 小白版）

先回答两个问题：

1. **功能名对不对？** 对。Nk 一共 26 个 `cl::opt` 开关（都在 `obfuscation/Obfuscation.cpp`），
   我上一版给的 `-enable-*` 全部来自源码，没有编造。
2. **有没有反调试？** 有：`-adb`（别名）＝ `-enable-adb`。另外还有反 Hook `-antihook`。
   Nk 还**自带**一整套 OLLVM 短名别名（`-bcf/-fla/-sub/-sobf/-split/...`），所以根本不用写长名。

---

## 1. 最省事：一行一个预设

```make
NK_DIR := $(NDK_ROOT)/toolchains/llvm/prebuilt/linux-arm64/nk

LOCAL_CPPFLAGS += -fpass-plugin=$(NK_DIR)/lib/libNk.so -mllvm -mid
```

| 短名 | 强度 | 适合 |
| --- | --- | --- |
| `-low` | 最轻（Sub+MBA+Split+BCF+StrEnc+ConstEnc） | 调试期、性能敏感 |
| `-mid` | 中等（再叠 Flatten+Vec+IndirBranch） | **默认推荐** |
| `-high` | 高（含 AntiDebug/AntiHook/FCO/FuncWra） | 核心模块 |
| `-max` | 极限（BCF 100%/迭代、CSM 双层、512→128 向量） | 压测/交付 |

> 上游本来只有 `-medobf / -maxobf`；本 kit 已打好补丁，补了 `-mid / -max / -ibr / -ollvm_print`。

---

## 2. 逐项开（复制即用）

```make
# ===== OLLVM-Next (Nk) ====================================================
NK_DIR  := $(NDK_ROOT)/toolchains/llvm/prebuilt/linux-arm64/nk
NK_FLAG := -fpass-plugin=$(NK_DIR)/lib/libNk.so

include $(CLEAR_VARS)
LOCAL_MODULE    := native-lib
LOCAL_SRC_FILES := native-lib.c core.c vm.c

LOCAL_CFLAGS   += $(NK_FLAG)     # C
LOCAL_CPPFLAGS += $(NK_FLAG)     # C++

# ---- 想开哪个加哪个（短名 = 长名的别名）----
LOCAL_CPPFLAGS += -mllvm -sobf       # 字符串加密      = -enable-strcry
LOCAL_CPPFLAGS += -mllvm -constenc   # 常量加密        = -enable-constenc
LOCAL_CPPFLAGS += -mllvm -bcf        # 虚假控制流      = -enable-bcfobf
LOCAL_CPPFLAGS += -mllvm -fla        # 控制流平坦化    = -enable-cffobf
LOCAL_CPPFLAGS += -mllvm -sub        # 指令替换        = -enable-subobf
LOCAL_CPPFLAGS += -mllvm -split      # 基本块切分      = -enable-splitobf
LOCAL_CPPFLAGS += -mllvm -ibr        # 间接跳转        = -enable-indibran
LOCAL_CPPFLAGS += -mllvm -mba        # MBA             = -enable-mbaobf
LOCAL_CPPFLAGS += -mllvm -vec        # 向量混淆        = -enable-vobf
LOCAL_CPPFLAGS += -mllvm -csm        # 混沌状态机      = -enable-csmobf
LOCAL_CPPFLAGS += -mllvm -fw         # 函数包装        = -enable-funcwra
LOCAL_CPPFLAGS += -mllvm -fco        # 函数调用混淆    = -enable-fco
LOCAL_CPPFLAGS += -mllvm -adb        # 反调试          = -enable-adb
LOCAL_CPPFLAGS += -mllvm -antihook   # 反 Hook/完整性  = -enable-antihook
LOCAL_CPPFLAGS += -mllvm -ollvm_print # 打印配置       = -obf-verbose

include $(BUILD_SHARED_LIBRARY)
```

> `-fla` 与 `-csm` 二选一（都是平坦化，`-csm` 更强更慢）。
> `-fco` 在 Android 上靠 `dlopen/dlsym` 解析符号，兼容性差，谨慎开。

---

## 3. 短名总表（源码里真实存在）

| 短名 | 等价长名 | 作用 |
| --- | --- | --- |
| `-bcf` | `-enable-bcfobf` | 虚假控制流 |
| `-fla` `-cff` `-cffobf` `-flatten` `-flattening` | `-enable-cffobf` | 控制流平坦化 |
| `-sub` | `-enable-subobf` | 指令替换 |
| `-sobf` `-strenc` | `-enable-strcry` | 字符串加密（含 anti-dump） |
| `-constenc` | `-enable-constenc` | 常量加密 |
| `-split` | `-enable-splitobf` | 基本块切分 |
| `-ibr` `-indibr` `-indibran` | `-enable-indibran` | 间接跳转 |
| `-mba` | `-enable-mbaobf` | 混合布尔算术 |
| `-vec` `-vobf` | `-enable-vobf` | 向量混淆 |
| `-csm` | `-enable-csmobf` | 混沌状态机 |
| `-fw` `-funcwra` | `-enable-funcwra` | 函数包装 |
| `-fco` | `-enable-fco` | 函数调用混淆 |
| `-adb` | `-enable-adb` | **反调试** |
| `-antihook` | `-enable-antihook` | 反 Hook / 代码完整性 |
| `-acd` | `-enable-acdobf` | ObjC/Swift 元数据（Android 无用） |
| `-allobf` | `-enable-allobf` | 全部 pass |
| `-low` `-mid` `-high` `-max` | `-enable-lowobf/-medobf/-highobf/-maxobf` | 预设 |
| `-ollvm_print` | `-obf-verbose` | 打印配置/统计（更细：`-obf-trace`） |

长名写法同样可用（`-mllvm -enable-adb` 等）。

---

## 4. 数值参数（`-bcf_prob=70` 这种）

Nk 里它们不是命令行开关，而是**配置项**。两种写法：

**A. 环境变量**（ndk-build 前 export，最省事）

```bash
export BCF_PROB=70 BCF_LOOP=2 SUB_LOOP=1 SPLIT_NUM=3
ndk-build NDK_PROJECT_PATH=. APP_ABI=arm64-v8a
```

| 想要 | 环境变量 |
| --- | --- |
| BCF 概率 / 次数 / 复杂度 | `BCF_PROB` / `BCF_LOOP` / `BCF_COMPLEXITY` |
| 指令替换概率 / 次数 | `SUB_PROB` / `SUB_LOOP` |
| 基本块切刀数 | `SPLIT_NUM` |
| 字符串加密概率 / 抗 dump | `STRCRY_PROB` / `STRCRY_ANTIDUMP=1` |
| 常量加密轮数 / 份额 / Feistel | `CONSTENC_TIMES` / `CONSTENC_KSHARE` / `CONSTENC_FEISTEL=1` |
| MBA 概率 / 层数 | `MBA_PROB` / `MBA_LAYERS` |
| 向量概率 / 位宽 | `VOBF_PROB` / `VOBF_WIDTH=128` |
| 函数包装概率 / 层数 | `FW_PROB` / `FW_TIMES` |
| 反调试概率 | `ADB_PROB` |
| 固定随机种子 | `AES_SEED=0x1337` |

**B. TOML**（可提交进仓库，支持按模块/函数细调）

```make
LOCAL_CPPFLAGS += -mllvm -nk-config=$(LOCAL_PATH)/nk-native.toml
```

```toml
[passes.bcf]
enabled = true
probability = 70        # ← -bcf_prob=70
iterations = 2          # ← -bcf_loop=2

[passes.substitution]
enabled = true
iterations = 1          # ← -sub_loop=1

[passes.split_blocks]
enabled = true
splits = 3              # ← -split_num=3
```

---

## 5. 拿老 OLLVM 配置直接套：哪些行能留

| 老写法 | 现在怎么写 | 说明 |
| --- | --- | --- |
| `-mllvm -bcf` | ✅ 原样 | 有别名 |
| `-mllvm -fla` | ✅ 原样 | 有别名 |
| `-mllvm -sub` | ✅ 原样 | 有别名 |
| `-mllvm -sobf` | ✅ 原样 | 有别名 |
| `-mllvm -split` | ✅ 原样 | 有别名 |
| `-mllvm -ibr` | ✅ 原样（本 kit 补丁） | 上游叫 `-indibr` |
| `-mllvm -ollvm_print` | ✅ 原样（本 kit 补丁） | 上游叫 `-obf-verbose` |
| `-mllvm -bcf_prob=70` | ⚠️ 改环境变量 `BCF_PROB=70` 或 TOML | 不是命令行开关 |
| `-mllvm -bcf_loop=2` | ⚠️ `BCF_LOOP=2` / TOML | 同上 |
| `-mllvm -sub_loop=1` | ⚠️ `SUB_LOOP=1` / TOML | 同上 |
| `-mllvm -split_num=3` | ⚠️ `SPLIT_NUM=3` / TOML | 同上 |
| `-mllvm -icall` | ❌ 无；最近似 `-fco`（Android 慎用） | 没有「间接调用」pass |
| `-mllvm -igv` | ❌ 无；最近似 `-constenc` + `CONSTENC_TOGV=1` | 没有「间接全局变量」pass |
| `-mllvm -fncmd` | ❌ 无；最近似 `-fw` | 没有函数名控制混淆 |
| `-mllvm -protect_maps` | ❌ 无；近似 `-sobf` + `STRCRY_ANTIDUMP=1` | 没有 ELF 段 mprotect |
| `-mllvm -protect_text` | ❌ 无；近似 `-antihook` | 代码段自校验在 antihook 里 |

`-O0/-O1/-O2/-O3/-Os/-Oz` 照旧，直接写在 `LOCAL_CFLAGS` 里。

---

## 6. 三条提醒

1. **别全开**：手机内存有限，每个源文件都会跑一遍全部 pass。建议 `-sobf -constenc -bcf -split`
   起步，编译不 OOM 再加。
2. **`-fpass-plugin=` 放模块级**（`LOCAL_CFLAGS/LOCAL_CPPFLAGS`），不要放 `APP_CFLAGS` 全局。
3. **验证**：`readelf -sW libxxx.so` 看私有符号是否被改名、`strings libxxx.so | grep 你的明文`
   应为空；整体自检用 `nk/bin/verify.sh`。

改完源码里的别名（`apply-short-flags.sh --revert` 之类）后记得**重新编译插件**：
`nk/bin/build-plugin.sh --llvm-dir <llvm-21 cmake 目录>`。
