# Nk (OLLVM-Next) × Android NDK r29 — 故障排查

每条格式：**现象 → 原因 → 处理**。命令里的变量沿用 `USAGE.md` 的约定：

```bash
export NDK=/opt/android-ndk-r29
export PRE=$NDK/toolchains/llvm/prebuilt/linux-arm64
export KIT=$PRE/nk
export CC26=$PRE/bin/aarch64-linux-android26-clang
```

---

## 1. `unable to load plugin ... undefined symbol` / 找不到 `llvmGetPassPluginInfo`

**现象**
```
clang: error: unable to load plugin '/.../nk/lib/libNk.so':
  .../libNk.so: undefined symbol: _ZN4llvm11PassBuilder...
```
或 `cannot find llvmGetPassPluginInfo`。

**原因**
1. 插件被挂到了**原版** `clang-21`（静态链接、无 `.dynsym`），进程内没有 LLVM 符号可解析；
2. 插件产物被 `--strip-all` 剥掉了 `.dynsym`，入口符号不在；
3. `.plugin-capable` 缺失时包装器本来就**不注入**，但你可能用显式 `-fpass-plugin=` 绕过了包装器。

**处理**
```bash
# 1) 确认插件入口与架构
llvm-nm -D --defined-only $KIT/lib/libNk.so | grep llvmGetPassPluginInfo
llvm-readelf -h $KIT/lib/libNk.so | grep -E 'Class|Machine'

# 2) 确认目标 clang 是否导出 LLVM 符号（0 = 静态链接，必须重编）
llvm-readelf --dyn-syms -W $PRE/bin/clang-21 | grep -c PassBuilder
$KIT/bin/install-plugin.sh --check          # 同一检查的封装，退出码 0 才可用

# 3) 重编 clang（导出符号）+ 重装插件 + 写标记
$KIT/bin/build-clang.sh --ndk "$NDK" --work ~/nk-llvm --jobs "$(nproc)"
# 或 clang 已重编过，只重装插件：
$KIT/bin/install-plugin.sh $KIT/lib/libNk.so
ls -l $KIT/lib/.plugin-capable               # 必须存在

# 4) 复核
$KIT/bin/verify.sh --api 26 --abi arm64-v8a --preset mid
```

---

## 2. `unknown argument: '-fpass-plugin=...'`

**现象**
```
clang: error: unknown argument: '-fpass-plugin=/.../libNk.so'
```

**原因**
1. 参数落到了 **cc1** 而不是 driver：`-cc1`/`-cc1as` 调用不接受 driver 级选项（包装器已对这类调用禁用注入，但你手工拼参数时会踩）；
2. 目标 clang 编译时关了插件支持（`CLANG_PLUGIN_SUPPORT=OFF`）：driver 层认这个选项、cc1/前端侧不认，
   自定义构建里就会直接报 unknown argument；本 NDK 的原版 clang 则是先过 driver、到加载阶段才失败（见第 1 条）；
3. 整串参数被当成一个 token 传给编译器（Gradle `cFlags`、CMake 单字符串 `CMAKE_C_FLAGS` 拼错时常见）。

**处理**
```bash
# 只通过 driver 调用（per-API 包装器 / clang / clang++），不要自己调 -cc1
NK=1 NK_PRESET=mid $CC26 -O2 -shared -fPIC -o /tmp/x.so demo.c

# 预览真实命令行，确认 -fpass-plugin 出现在 driver 层
NK=1 $CC26 -### -O2 -shared -fPIC demo.c 2>&1 | tr ' ' '\n' | grep fpass-plugin

# 传统形式（frontend plugin）也可以，且总闸要显式给
$PRE/bin/clang --target=aarch64-linux-android26 --sysroot=$PRE/sysroot \
  -Xclang -load -Xclang $KIT/lib/libNk.so -mllvm -nk \
  -mllvm -nk-config=$KIT/config/nk.toml \
  -O2 -shared -fPIC -o /tmp/x.so demo.c
```

CMake 里逐 token 写，不要拼串：
```cmake
target_compile_options(native-lib PRIVATE -fpass-plugin=${NK_PLUGIN} -mllvm -nk)
```

---

## 3. LLVM 版本不匹配导致崩溃

**现象**
编译到一半 `Segmentation fault`、`LLVM ERROR: out of memory` 之后立刻 abort、或
`symbol lookup error` / `stack smashing detected`，且换了套件就消失。

**原因**
pass plugin 与宿主 clang 必须**完全同版本、同构建配置**。本 NDK 的 clang 是
`21.0.0 (based on r563880c, Android dev build)`；用 Termux 的 llvm、Ubuntu 的 llvm-21 或别的 21.x
头文件编出的插件，`llvm::` 结构布局/虚表可能不同，加载不报错、跑起来就崩。

**处理**
```bash
# 看目标 clang 的确切版本
$PRE/bin/clang-21 --version

# 只用同一条构建链产物作为插件的 LLVM_DIR
$KIT/bin/build-plugin.sh --llvm-dir ~/nk-llvm/build-android/lib/cmake/llvm --api 26
# 完整重来（含 clang 重编）
$KIT/bin/build-clang.sh --llvm-tag llvmorg-21.0.0 --clean --jobs "$(nproc)"

# 路径 B 反过来同理：插件必须用 Termux 的 LLVM 编，不能拿路径 A 的插件配 Termux clang
llvm-config --version
$KIT/bin/build-plugin.sh --llvm-dir "$(llvm-config --cmakedir)" --mode native
```

---

## 4. 插件架构不匹配（ELF machine）

**现象**
```
[nk-install] 插件 ELF machine: Advanced Micro Devices X86-64（期望含 AArch64）
[nk-install] 错误: 插件架构与 NDK prebuilt（linux-arm64）不匹配
```
或加载时报 `wrong ELF class` / `invalid ELF header`。

**原因**
在 x86_64 构建机上 `build-plugin.sh --mode native` 编出了 x86_64 插件，却塞进 `linux-arm64`
prebuilt；或 `--abi` 给错。

**处理**
```bash
llvm-readelf -h $KIT/lib/libNk.so | grep -E 'Class|Machine'   # 期望 ELF64 / AArch64

# 交叉编（host=x86_64 时必须显式 cross）
$KIT/bin/build-plugin.sh --abi arm64-v8a --api 26 --mode cross \
  --llvm-dir ~/nk-llvm/build-android/lib/cmake/llvm

# 强校验后再装
NK_WANT_MACHINE=AArch64 $KIT/bin/install-plugin.sh $KIT/lib/libNk.so
# 其它 ABI 只在确有必要时：--abi armeabi-v7a | x86_64（均非 Tier 0）
```

---

## 5. 交叉编译 sysroot / `libc++_shared.so` 缺失

**现象**
插件加载时 `cannot locate symbol`、`library "libc++_shared.so" not found`；或用 `nk-clang`
时 `stdio.h not found` / `cannot find crtbegin_so.o`。

**原因**
1. 插件被写成依赖 `libc++_shared.so`（用了 `ANDROID_STL=c++_shared`），而宿主是静态 clang，没人为它 `dlopen` 这个运行库；
2. `nk-clang` 的 `--sysroot` 指错（目标 prebuilt 里没有 `sysroot/`，指向了不完整目录）。

**处理**
```bash
# 插件侧：强制静态 C++ 运行时（build-plugin.sh 已内置）
$KIT/bin/build-plugin.sh --abi arm64-v8a --mode cross \
  --llvm-dir ~/nk-llvm/build-android/lib/cmake/llvm
llvm-readelf -d $KIT/lib/libNk.so | grep NEEDED     # 期望没有 libc++_shared.so

# 编译侧：确认 sysroot 与 triple 正确
$KIT/bin/nk-clang --abi arm64-v8a --api 26 --show -O2 -c demo.c
ls $PRE/sysroot/usr/include/stdio.h
# 目标 prebuilt 缺 sysroot 时，改指向完整 NDK 的同名目录：
NK_HOST_CLANG=/path/clang-21 $KIT/bin/nk-clang --abi arm64-v8a --api 26 -c demo.c
# 或直接补 --sysroot（nk-clang 不接受该参数，请用原生 clang 形式）：
$PRE/bin/clang --target=aarch64-linux-android26 --sysroot=$PRE/sysroot -c demo.c
```

---

## 6. `-fno-rtti` 冲突

**现象**
`undefined symbol: _ZTIN4llvm...`、`typeinfo for llvm::...`、或 `cannot use dynamic_cast with -fno-rtti`。

**原因**
LLVM 构建用 `-DLLVM_ENABLE_RTTI=OFF`（本 kit 的 `build-clang.sh` 也是），插件若带 RTTI 或用了
`dynamic_cast`/`typeid`，符号在宿主里不存在；反之宿主带 RTTI、插件不带，同样会在 `llvm::isa` 边界出问题。

**处理**
```bash
# 插件的编译选项必须与宿主一致
$KIT/bin/build-plugin.sh --mode cross --llvm-dir ~/nk-llvm/build-android/lib/cmake/llvm
# native 模式脚本已加 -fno-rtti；手工 CMake 时补齐：
cmake -S $KIT/src -B $KIT/.build/plugin -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DLLVM_DIR=~/nk-llvm/build-android/lib/cmake/llvm \
  -DCMAKE_CXX_FLAGS="-fno-rtti -fno-exceptions"

# 复核：插件不应引用 typeinfo/vtable-for 之类
llvm-nm -D -u $KIT/lib/libNk.so | grep -E 'typeinfo|_ZTI|_ZTV' || echo "no RTTI refs"
```

改完源码里不要用 `dynamic_cast`，统一用 `llvm::dyn_cast`/`isa`。

---

## 7. LLVM 构建 OOM / 磁盘不足 / tablegen 交叉问题

**现象**
`c++: fatal error: Killed signal terminated program cc1plus`（OOM killer）、
`No space left on device`、或交叉配置阶段报
`llvm-tblgen: error while loading shared libraries` / `Could not find llvm-tblgen`。

**原因**
1. LLVM/Clang 全量构建单文件峰值内存很高，`-j8` 在 16 GB 机器上就会 OOM；
2. 源码 1.5 GB + 构建树 30–40 GB，`$HOME` 分区常见只有 20 GB；
3. 交叉编译必须先用**宿主编译器**构建 host 版 `llvm-tblgen`/`clang-tblgen`，否则会用目标架构的
   tblgen 去跑（无法执行）或干脆找不到。

**处理**
```bash
# 内存：降并行、加 swap、只用链接单线程（脚本内置 LLVM_PARALLEL_LINK_JOBS=1）
$KIT/bin/build-clang.sh --jobs 4 --work /data/nk-llvm --clean
sudo fallocate -l 16G /swapfile && sudo chmod 600 /swapfile \
  && sudo mkswap /swapfile && sudo swapon /swapfile

# 磁盘：换到大分区并预留 ≥40 GB
df -h /data; NK_WORK=/data/nk-llvm $KIT/bin/build-clang.sh --jobs 8

# 只补 tablegen（脚本第 2 步做的事，可单独重跑）
cmake -S ~/nk-llvm/llvm-project/llvm -B ~/nk-llvm/build-host-tblgen -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DLLVM_TARGETS_TO_BUILD="" -DLLVM_ENABLE_PROJECTS=clang \
  -DLLVM_BUILD_TOOLS=OFF -DLLVM_INCLUDE_TESTS=OFF
cmake --build ~/nk-llvm/build-host-tblgen --target llvm-tblgen clang-tblgen --parallel 8
# 交叉配置时显式喂给 CMake（脚本已自动传 -DLLVM_TABLEGEN/-DCLANG_TABLEGEN）
```

`dmesg | grep -i -E 'oom|killed process'` 可确认是否被 OOM killer 干掉。

---

## 8. 混淆后体积 / 编译耗时爆炸

**现象**
`.so` 从 2 MB 涨到 30 MB+；单个 TU 编译从 3 s 变 3 min；链接阶段内存打满。

**原因**
叠加高位参数：BCF `probability + iterations + junk_asm + entropy_chain`、CSM 嵌套派发、
VOBF 256/512 位、ConstEnc `globalize`、以及对 **整个 .so 全量**应用 `high`/`max`。

**处理**
```bash
# 1) 先定位是哪个 pass 在吃时间/体积
NK=1 NK_PRESET=mid $CC26 -O2 -shared -fPIC -mllvm -obf-trace -o /tmp/obf.so demo.c 2>/tmp/trace.log
grep -c 'Running' /tmp/trace.log

# 2) 逐项降档（环境变量优先，便于 A/B）
NK=1 NK_PRESET=mid BCF_PROB=35 BCF_JUNKASM=0 BCF_ENTROPY_CHAIN=0 \
  MBA_LAYERS=2 VOBF_WIDTH=128 VOBF_PROB=30 CSM_NESTED=0 CSM_MAXBLOCKS=5000 \
  CONSTENC_TOGV=0 SPLIT_NUM=2 \
  $CC26 -O2 -shared -fPIC -o /tmp/obf.so demo.c

# 3) 或者用 policy 只保护核心函数，其余降档
#    （config/nk.toml 第二条 policy 就是「JNI/初始化函数全关」）
NK=1 NK_PRESET=low \
  NK_CONFIG=$KIT/config/nk.toml $CC26 -O2 -shared -fPIC -o /tmp/obf.so demo.c

# 4) 量化
/usr/bin/time -v $CC26 ... 2>&1 | grep -E 'Elapsed|Maximum resident'
stat -c '%s' /tmp/obf.so
```

---

## 9. 混淆后 App 崩溃或 ANR（四类高发原因）

**现象**：安装后启动即闪退 / 随机重启 / 界面卡死；`logcat` 里 `signal 6`、`exit(137)`、或
`Fatal signal 11 (SIGSEGV)`，地址落在自己 `.so` 内。

**原因与处理**

**(a) anti_debugging 误判**
`prctl(PR_SET_DUMPABLE, 0)`、`/proc/self/status` 的 `TracerPid` 直读、`SYS_exit_group(137)` 暴力退出；
真机上的 crashpad、厂商 profiler、`adb shell am` 注入都可能被当成调试器。
```bash
# 确认是暴力退出而非真崩
adb logcat -b all -v threadtime | grep -E 'exit_group|signal 6|137'
# 关掉（kit 默认就是关的）
#   [passes.anti_debugging] enabled = false
unset ADB
NK=1 NK_PRESET=mid NK_CONFIG=/path/your.toml $CC26 ...
grep -A3 'anti_debugging' $KIT/config/nk.toml
```

**(b) FCO 的 `dlopen` 限制**
`function_call_obfuscate` 把直接调用改成运行期 `dlopen`+`dlsym`；Android 的 linker namespace 白名单、
`RTLD_NOW` 立即绑定、以及被混淆掉的外部符号名都会让它返回 `NULL` → 空指针跳转。
```bash
# 先关掉验证（kit 默认关闭）
unset FCO
# 确需开启时：只对自有符号成立，且要保留符号可见性
#   [passes.function_call_obfuscate] enabled = true / symbol_config_path = "fco-allow.txt"
adb logcat | grep -iE 'dlopen|dlsym|library .* not found'
```

**(c) `stack_confusion` 破坏栈回溯**
`split_blocks.stack_confusion` 在 arm64 上注入 `str/ldr` 栈干扰，`libunwind`/breakpad 拿到的栈帧错乱，
崩溃上报里全是 `??`，甚至 unwinder 自己踩坏内存。
```bash
# 关掉栈干扰，保留切分
NK=1 NK_PRESET=mid SPLIT_STACKCONF=0 $CC26 -O2 -shared -fPIC -o /tmp/x.so demo.c
# 或配置里 [passes.split_blocks] stack_confusion = false
adb logcat | grep -E 'libunwind|unwind|backtrace' | head
```

**(d) `vector width 256/512` 在 arm64 退化**
arm64 只有 NEON（128-bit），`width = 256/512` 会走标量模拟路径，代码膨胀且在某些 CPU 上触发
`SIGILL`/性能断崖；`max` 预设默认 512。
```bash
# 钉死 128（所有预设与 config/nk.toml 都已这样做）
NK=1 NK_PRESET=max VOBF_WIDTH=128 $CC26 -O2 -shared -fPIC -o /tmp/x.so demo.c
adb shell getprop ro.product.cpu.abilist
```

**通用定位流程**
```bash
adb logcat -c; adb shell am start -n com.example/.MainActivity; sleep 3
adb logcat -d -b crash | tail -80
$PRE/bin/llvm-symbolizer --obj=libnative-lib.so <地址>   # 需保留未 strip 的版本对照
```

---

## 10. 静态初始化 / 异常问题

**现象**
在 `JNI_OnLoad` 之前就崩（`.init_array` 构造函数里）、`std::terminate` 无栈、
`__cxa_throw` 后落入 `abort`、或 C++ 全局对象析构顺序错乱。

**原因**
1. 全局构造/析构（`_GLOBAL__sub_I_*`、`*_init`/`*_fini`、`__aeabi_*`）被 CFG 改造或被字符串加密影响；
2. 异常路径依赖精确的栈展开信息，而 `stack_confusion` / 大范围 BCF 让 `personality` 与 `.eh_frame`
   对不上；
3. `string_encryption.anti_dump` 在返回时清零的缓冲区被构造函数继续使用。

**处理**
```bash
# 让初始化/异常敏感函数退出高强度档位（policy 写法见 USAGE.md 第 5 节第二条）
#   function_regex = "^(JNI_OnLoad|JNI_OnUnload|__aeabi_.*|.*_init|.*_fini)$"
#   passes.string_encryption.enabled = false / bcf / csm / flattening / indirect_branch = false

# 复现与定位
NK=1 NK_PRESET=mid SPLIT_STACKCONF=0 $CC26 -O2 -shared -fPIC -o /tmp/x.so demo.c
readelf -S /tmp/x.so | grep -E 'init_array|eh_frame'

# 只要构建能过、运行会崩，先降到 low 判定范围
NK=1 NK_PRESET=low $CC26 -O2 -shared -fPIC -o /tmp/low.so demo.c
```

必要时对抛出异常的函数加 `-fno-exceptions` 重写为错误码，或对该 TU 单独用 `low` 预设。

---

## 11. strip 与 anti_dump

**现象**
A：`strip` 之后 `dlsym("Java_...")` 返回 `NULL`、`RegisterNatives` 失败，或 FCO 全挂；
B：`strings libxxx.so | grep <密钥>` 仍能搜到明文。

**原因**
A：`--strip-all` 把 `.dynsym` 也删了；或 strip 顺序错（先 strip 后混淆无意义）；
B：`anti_dump` 没开，或字符串被 `skip_content` 命中（例如写了过宽的跳过规则）。

**处理**
```bash
# 只剥调试/符号表，保留动态符号表
$PRE/bin/llvm-strip --strip-unneeded libnative-lib.so
llvm-nm -D --defined-only libnative-lib.so | grep -E 'Java_|JNI_'   # 必须还在
llvm-readelf -S libnative-lib.so | grep -E '\.dynsym|\.symtab'      # .dynsym 必须在

# 顺序：混淆编译 -> strip -> 校验
NK=1 NK_PRESET=mid $CC26 -O2 -shared -fPIC -o lib.so demo.c
$PRE/bin/llvm-strip --strip-unneeded lib.so
strings -a lib.so | grep -c 'NK_SECRET_TOKEN'                    # 期望 0

# 确认 anti_dump 生效
grep -A3 'string_encryption' $KIT/config/nk.toml                 # anti_dump = true
$KIT/bin/verify.sh --preset mid                                     # 内含明文断言
```

---

## 12. CMake 缓存旧编译器 / 开关不生效

**现象**
重编了 `clang-21`，但 CMake 仍行为异常；或设置了 `NK=1` 重新构建却没混淆；
`cmake --build` 直接跳过（ninja: no work to do）。

**原因**
`CMakeCache.txt` 缓存了编译器路径与编译参数；Gradle 的 daemon 缓存了进程环境；
ninja 因为输入未变而不重编。

**处理**
```bash
# 看缓存里到底用的哪个编译器
grep -E 'CMAKE_(C|CXX)_COMPILER:|CMAKE_C_FLAGS:' build-arm64/CMakeCache.txt

# 清干净重配（最省事）
rm -rf build-arm64 && cmake -S . -B build-arm64 -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE=$NDK/build/cmake/android.toolchain.cmake \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 -DANDROID_STL=c++_static

# 只换编译器
cmake -S . -B build-arm64 -DCMAKE_C_COMPILER=$PRE/bin/clang -DCMAKE_CXX_COMPILER=$PRE/bin/clang++

# 强制重编
cmake --build build-arm64 --clean-first

# Gradle：daemon 环境要重启
./gradlew --stop
./gradlew clean assembleRelease
```

---

## 13. 真机 clang 无法运行（架构 / 权限）

**现象**
```
/data/.../clang-21: cannot execute: Exec format error
bash: /.../clang-21: Permission denied
```

**原因**
1. 把 x86_64 二进制放进了 arm64 prebuilt（或反过来）；
2. 文件落在 `/sdcard`（noexec/noexec 挂载、FUSE 权限），或拷贝时丢了 `x` 位；
3. `build-clang.sh` 装好后权限是 `0700`，普通用户/其它 app 用户无法执行。

**处理**
```bash
# 架构核对
$PRE/bin/llvm-readelf -h $PRE/bin/clang-21 | grep Machine        # 期望 AArch64
file $PRE/bin/clang-21

# 状态自检（会打印 ELF 类型、.dynsym、插件能力、bin/clang 是否包装器）
$KIT/bin/nk-status.sh

# 权限与位置：放在 $HOME 而不是 /sdcard
cp $PRE/bin/clang-21 ~/clang-21 && chmod 700 ~/clang-21 && ~/clang-21 --version

# 绝对装不上时的兜底：让包装器指向可执行的等价物
NK_REAL_CLANG=$HOME/clang-21 NK=1 $CC26 -O2 -shared -fPIC -o /tmp/x.so demo.c
# 走路径 B 也能绕开：用 Termux 的 clang 交叉编译
$KIT/bin/nk-clang --abi arm64-v8a --api 26 --preset mid -O2 -shared -fPIC -o /tmp/x.so demo.c
```

---

## 14. GitHub Actions 构建超时 / 磁盘不足

**现象**
`The job running on runner ... has exceeded the maximum execution time of 350 minutes`；
或 `No space left on device`、`Killed`（OOM）。

**原因**
`ci/build-nk-ndk.yml` 已按「4 核 / 14 GB 空闲」的默认 runner 做了保守配置（`timeout-minutes: 350`、
`jlumbroso/free-disk-space`、`-DLLVM_PARALLEL_LINK_JOBS=1`），但 LLVM 全量构建在 4 核上仍需 4–6 小时，
期间源码 + 构建树很容易超过剩余磁盘。

**处理**
```bash
# 1) 先释放磁盘（workflow 里已做，手动补跑也有效）
#    android / dotnet / haskell / docker-images / large-packages 全清，可腾出 ~30 GB
sudo rm -rf /usr/share/dotnet /opt/ghc /usr/local/lib/android

# 2) 把工作目录放到 runner 的临时盘，并降并行
$KIT/bin/build-clang.sh --ndk "$NDK" --work "$RUNNER_TEMP/llvm" --jobs 4 \
  --out-dir "$PWD/artifacts"

# 3) 只编一次 clang，插件单独重跑（缩短重试时间）
$KIT/bin/build-clang.sh --skip-plugin --out-dir "$PWD/artifacts"
$KIT/bin/build-plugin.sh --llvm-dir "$RUNNER_TEMP/llvm/build-android/lib/cmake/llvm" \
  --abi arm64-v8a --no-install

# 4) 根治：自托管 8 核 / 32 GB runner（8 核约 2 小时）
#    或拆成两个 job：构建 clang（cache 源码+构建树） / 构建插件
```

---

## 15. `NK=0` 仍被混淆 / 环境变量残留

**现象**
明确写了 `NK=0`，产物却明显变大；或某个 pass 关不掉。

**原因**
1. 单 pass 环境变量是「**存在即开启**」（`getenv("BCF")`），`BCF=0` 也照样开；
2. 显式 `NK_CONFIG=` 或 `-mllvm -nk-config=` 会被视为「要混淆」，自动置位总闸；
3. Gradle daemon / CI 的 `env` 里挂着上次的 `NK_PRESET`；
4. `./nk.toml` 被自动发现（不会自动开总闸，但会提供参数）。

**处理**
```bash
# 1) 揪出残留
env | grep -E '^(NK|BCF|MBA|STRCRY|CONSTENC|VOBF|VEC|CSM|SPLIT|INDIBR|FUNCWRA|FCO|ADB|ANTIHOOK|VERBOSE|TRACE)'

# 2) 一次性清干净（脚本已内置）
unset NK NK_PRESET NK_CONFIG
unset BCF STRCRY CONSTENC MBA SPLIT CSM FCO ADB ANTIHOOK FUNCWRA VERBOSE TRACE
. $KIT/bin/nk-env.sh off

# 3) 验证是否真的没注入了
NK=0 $CC26 -### -O2 -c demo.c 2>&1 | grep -c fpass-plugin    # 期望 0
stat -c '%s' /tmp/plain.so

# 4) Gradle 场景
./gradlew --stop
```

---

## 16. 编译卡在 0% CPU / 日志刷屏

**现象**
编译进程占 0% CPU 不退出，加上 `-obf-verbose`（或 `VERBOSE=1`）时尤其明显；`Ctrl-C` 后才继续。

**原因**
`-obf-verbose` 会为每个 pass/函数打一行 `Running X On Y`，大模块下输出量轻松超过 64 KB 的 stderr
管道缓冲；写端阻塞、读端没消费，就成了「假死」。

**处理**
```bash
# 别用 verbose；改用 trace（每 pass 只有标记行）
NK=1 NK_PRESET=mid $CC26 -mllvm -obf-trace -O2 -shared -fPIC -o /tmp/x.so demo.c 2>/tmp/trace.log

# 必须看详细日志时，重定向到文件而不是管道
NK=1 NK_PRESET=mid VERBOSE=1 $CC26 -mllvm -obf-verbose -O2 -c demo.c 2>/tmp/verbose.log
tail -50 /tmp/verbose.log

# 抓现场
ps -o pid,pcpu,stat,wchan:20,cmd -C clang-21
cat /proc/<pid>/stack 2>/dev/null | head
```

---

## 17. TOML `[[policy]]` 不生效

**现象**
写了 `module_regex = "crypto"` 或 `function_regex = "verifyLicense"`，但对应函数强度没变。

**原因**
1. `module_regex` 匹配的是**该 TU 的源文件路径**（可能是 `../src/crypto/aes.c` 或绝对路径），
   不是模块名；
2. 引擎是 `std::regex_search`**子串搜索**、ECMAScript 语法：PCRE 扩展（lookbehind、`\p{...}`、条件组）
   直接抛 `regex_error` 被静默跳过；TOML 双引号串里 `\d`/`\.` 必须写成 `"\\d"`/`"\\."`；
3. `function_regex` 先匹配 mangled 名，再匹配 demangle 名——C++ 里命中失败的典型是只写了带参数的签名；
4. 预设与策略的合并顺序：策略 `preset` 先铺底、策略内 `passes.*` 覆盖；但**全局** `[passes.*]`
   若在策略里没写，会参与合并，容易让人误以为策略没生效；
5. 依赖 `./nk.toml` 自动发现时，命令行给 `-mllvm -nk-preset` 会**清空** policies（自动发现的模板被视为示例）。

**处理**
```bash
# 用 trace 看实际命中的函数与 pass
NK=1 NK_CONFIG=/abs/path/nk.toml $CC26 -mllvm -obf-trace -O2 -c crypto/aes.c 2>&1 | grep -i policy

# 转义与语法：ECMAScript，注意 \\ 与字符组
#   推荐写法：module_regex = ".*crypto.*"；function_regex = ".*verify.*|.*license.*"
#   非法正则会在 stderr 打 "[Nk] invalid ... regex in policy"

# 显式指定配置（避免自动发现与 preset 覆盖策略）
NK=1 NK_PRESET=mid NK_CONFIG=/abs/path/nk.toml \
  $CC26 -mllvm -nk-config=/abs/path/nk.toml -O2 -shared -fPIC -o /tmp/x.so demo.c
# 注意：-mllvm -nk-config 的优先级高于 NK_CONFIG；两者给同一个文件最省事

# 确认策略体本身生效：临时把该 policy 的 preset 改成 "low"，对比体积
stat -c '%s' /tmp/x.so
```
