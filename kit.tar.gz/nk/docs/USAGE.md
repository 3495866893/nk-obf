# Nk (OLLVM-Next) × Android NDK r29 — 使用手册

目标环境：NDK `29.0.14206865 (r29)`，`toolchains/llvm/prebuilt/linux-arm64`，clang `21.0.0`。
kit 版本见 `nk/VERSION`（`NK_KIT_VERSION=1.0.0`，上游 commit `56a6df14`）。

约定路径（下文全部沿用）：

```bash
export NDK=/opt/android-ndk-r29
export PRE=$NDK/toolchains/llvm/prebuilt/linux-arm64
export KIT=$PRE/nk                 # 本 kit
export CC26=$PRE/bin/aarch64-linux-android26-clang   # NDK per-API 包装器
```

---

## 0. 两条可用路径（先认清硬事实）

NDK 自带的 `bin/clang-21` 是**静态链接、无 `.dynsym`** 的 aarch64 可执行文件，进程内没有 LLVM
动态符号，`-fpass-plugin=` 必然失败（`unable to load plugin ... undefined symbol`）。
`bin/clang` 已被替换为 shell 包装器（源码即 `nk-ndk/clang`），它只做一件事：在 `NK=1`
且能力标记存在时，往命令行前面插 `-fpass-plugin=$KIT/lib/libNk.so`，然后 `exec clang-21`。

| 路径 | 做什么 | 先决条件 | 产物 |
| --- | --- | --- | --- |
| **A** | `nk/bin/build-clang.sh` 重编导出 LLVM 符号的 `clang-21`，编插件，写 `.plugin-capable` | 一台 Linux 构建机（≥8 核 / ≥16 GB / ≥40 GB）或 GitHub Actions | NDK 原生 `bin/clang` 直接带混淆 |
| **B** | `nk/bin/nk-clang` 用外部「能加载插件」的 clang 21（Termux llvm / 自编 LLVM 21）+ NDK sysroot 交叉编译 | 设备上 `llvm` 21 + `cmake` + `ninja` | 不重编 NDK clang |

两条路径共用同一个 `$KIT/lib/libNk.so` 与同一套 `config/`。

---

## 1. 一分钟快速开始

### 路径 A：重编 clang（成品化，推荐）

```bash
export NDK=/opt/android-ndk-r29
PRE=$NDK/toolchains/llvm/prebuilt/linux-arm64
KIT=$PRE/nk

# 1) 拉 llvm-project 21.0.0 -> 编 host tblgen -> 交叉编 clang -> 装进 NDK -> 编插件 -> 写标记
$KIT/bin/build-clang.sh --ndk "$NDK" --work ~/nk-llvm --jobs "$(nproc)"

# 2) 对照实验自检（NK=0 / NK=1 各编一次 hello.c）
$KIT/bin/verify.sh --api 26 --abi arm64-v8a --preset mid

# 3) 日常编译：一条命令
NK=1 NK_PRESET=mid \
  $PRE/bin/aarch64-linux-android26-clang -O2 -shared -fPIC -o libdemo.so demo.c

# 4) 脚本/构建系统里长期生效
. $KIT/bin/nk-env.sh mid
```

只编插件不重编 clang（clang 已重编过）：`$KIT/bin/build-plugin.sh --llvm-dir ~/nk-llvm/build-android/lib/cmake/llvm --api 26`。
状态自检：`$KIT/bin/nk-status.sh`、`$KIT/bin/install-plugin.sh --check`。

### 路径 B：外部插件版 clang（零重编，手机上可用）

```bash
# Termux 一次性准备
pkg install llvm cmake ninja git
KIT=/data/data/com.termux/files/home/ndk/toolchains/llvm/prebuilt/linux-arm64/nk

# 1) 本机编插件（必须与 Termux 的 llvm 同为 21.x）
$KIT/bin/build-plugin.sh --llvm-dir "$(llvm-config --cmakedir)" --mode native --jobs 4

# 2) 预览最终命令行（确认 --target/--sysroot/-fpass-plugin 都在）
$KIT/bin/nk-clang --abi arm64-v8a --api 26 --preset mid --show -O2 -shared -fPIC -o libdemo.so demo.c

# 3) 真正编译
$KIT/bin/nk-clang --abi arm64-v8a --api 26 --preset mid -O2 -shared -fPIC -o libdemo.so demo.c
# 或指定 clang： --clang $(command -v clang-21)  /  NK_HOST_CLANG=/path/clang-21
```

路径 B 不依赖 `.plugin-capable`，也不经过 NDK 包装器；`nk-clang` 直接把 `-fpass-plugin`
与 `NK_PRESET` / `NK_CONFIG` 交给外部 clang。

---

## 2. 环境开关矩阵

### 2.1 包装器 / 驱动层

| 变量 | 取值 | 默认 | 优先级 / 生效点 | 说明 |
| --- | --- | --- | --- | --- |
| `NK` | `0` / `1` | `0` | 总闸，`bin/clang` 包装器读 | 不设=完全透传（与原 clang 等价）。`1` 时才检查插件与能力标记 |
| `NK_PRESET` | `low`/`mid`/`high`/`max`/`csm_vec`/`csm_only`/`vec_only` | 不设（回退 TOML `[global] preset`，kit 为 `mid`） | 覆盖 TOML `[global] preset`，但**不覆盖**显式 `[passes.*]` 项 | 透传给插件；`NK_PRESET` 一旦存在也会自动打开混淆总闸 |
| `NK_CONFIG` | 绝对路径 | 包装器注入时默认 `$KIT/config/nk.toml` | 低于 `-mllvm -nk-config=`，高于 `./nk.toml` | 显式配置文件会被视为「要混淆」，自动打开总闸 |
| `NK_REAL_CLANG` | clang 路径 | `$PRE/bin/clang-21` | 包装器 / `install-plugin.sh` / `verify.sh` 都认 | 换真实编译器（例如 `clang-21.bak` 对比实验） |
| `NK_FORCE` | `0` / `1` | `0` | 包装器 | 忽略 `lib/.plugin-capable` 标记（你自己换了 clang 时用） |
| `NK_QUIET` | `0` / `1` | `0` | 包装器 | 静默包装器自身告警 |
| `NK_FPASS` | 字符串 | 由 `nk-env.sh` 导出为 `-fpass-plugin=...` | 供显式拼参数用 | 构建系统不吃环境变量时把它塞进编译参数 |
| `NK_HOST_CLANG` | clang 路径 | 空 | 仅 `nk-clang` | 等价 `--clang` |
| `NK_KIT_DIR` / `NDK_NK_PREBUILT` | 路径 | 由 `nk-env.sh` 导出 | 只读参考 | 在 CMake/Gradle 里定位 kit |

### 2.2 构建期（脚本）变量

| 变量 | 默认 | 使用方 | 说明 |
| --- | --- | --- | --- |
| `NDK` | 由 kit 位置推导 | `build-clang.sh` | 交叉工具链 / sysroot 来源 |
| `LLVM_TAG` | `llvmorg-21.0.0` | `build-clang.sh` | 必须 21.x，否则插件 ABI 崩 |
| `NK_WORK` | `$HOME/nk-llvm` | `build-clang.sh` | 源码 + 构建目录 |
| `API` | `26` | `build-clang.sh`（环境变量）；`build-plugin.sh` 用 `--api` | `ANDROID_PLATFORM` |
| `JOBS` | `nproc` | `build-clang.sh`（环境变量）；其余脚本用 `--jobs` | 并行度 |
| `NK_INSTALL_DIR` | 本 kit 所在 prebuilt | `build-clang.sh` | 覆盖安装目标 prebuilt |
| `NK_BUILD_DIR` | `$KIT/.build/plugin` | `build-plugin.sh` | 插件构建目录 |
| `LLVM_DIR` | 自动探测 `llvm-config --cmakedir` | `build-plugin.sh` | 必须与目标 clang 同版本、同构建树 |
| `NK_WANT_MACHINE` | `AArch64` | `install-plugin.sh` | 插件 ELF machine 期望值 |

### 2.3 插件内部（cl::opt / env）优先级

从高到低：**源码注解（`__attribute__((annotate))`）> TOML `[passes.*]` > `-mllvm -nk-preset` > TOML `[global] preset` > 编译期默认值**。
配置文件查找顺序：`-mllvm -nk-config=<path>` > `NK_CONFIG` > `./nk.toml`（当前目录自动发现**不会**自动开启混淆）。

> **陷阱**：单 pass 的环境变量（`BCF`、`STRCRY`、`ADB` …）是「存在即开启」，`BCF=0` 仍然会打开 BCF。
> 要关就 `unset BCF`，或在 TOML 里写 `enabled = false`。

---

## 3. 15 个 pass：CLI flag / env / 作用 / Android 建议

所有 `-enable-*` 都是 LLVM `cl::opt`，经 clang driver 传递时必须加 `-mllvm`：
`-mllvm -enable-bcfobf`。等价短别名也已注册（如 `-mllvm -bcf`、`-mllvm -maxobf`）。

| # | Pass | CLI flag（加 `-mllvm`） | Env（存在即开） | 作用 | Android 建议 |
| --- | --- | --- | --- | --- | --- |
| 1 | ANTIHOOK | `-enable-antihook` | `ANTIHOOK` | 函数入口序言校验（aarch64 `B .+4` 等内联 hook 特征）+ 飞行中 CFG 审计 + 代码自校验 + 直接 syscall + 三层反污染 | **默认关**。`check_integrity`/`direct_syscall` 在真机上易误判；只在核心 .so 开，且回归全部机型 |
| 2 | ACDOBF | `-enable-acdobf` | `ACDOBF` | ObjC/Swift 元数据打乱、method list 洗牌、dummy selector | **Android 无效**（Mach-O 专用），保持关 |
| 3 | FCO | `-enable-fco` | `FCO` | 直接调用改成运行期 `dlopen`/`dlsym`，抹掉外部符号导入 | **默认关**。Android 的 `dlopen` 白名单/命名空间限制多，且破坏符号可见性；需要 `-ldl` |
| 4 | ADB | `-enable-adb` | `ADB` | `/proc/self/status` TracerPid 直读、`prctl(PR_SET_DUMPABLE,0)`、调试寄存器、RDTSC/计数抖动、`SYS_exit_group(137)` | **默认关**。开发期必关；会打断 debugger/crashpad/部分 profiler |
| 5 | STRCRY | `-enable-strcry` | `STRCRY`/`SOBF`/`STRENC` | 双层 Vernam OTP + GF(2^8) 加密、乱序内联解密桩、返回时内存清零（anti-dump） | **必开**，性价比最高；配合 `force_content` 精确打击密钥类字符串 |
| 6 | CONSTENC | `-enable-constenc` | `CONSTENC` | 常量两阶段加密（MBA k-share / 4 轮 Feistel / 反调试 token 纠缠） | **开**。`share_count=3`、`feistel=true` 是体积/强度的平衡点 |
| 7 | SUBOBF | `-enable-subobf` | `SUBOBF`/`SUB` | 算术/位运算替换为多项式与循环恒等式 | **开**，`iterations=1` 时膨胀可控 |
| 8 | MBAOBF | `-enable-mbaobf` | `MBAOBF`/`MBA` | 混合布尔算术（42 条恒等式 + 上下文噪声 + 状态相关屏障） | **开**，`layers=2`；`layers=3` 留给白盒化的核心函数 |
| 9 | SPLITOBF | `-enable-splitobf` | `SPLITOBF`/`SPLIT` | 基本块切分 + 不透明谓词链 + 栈指针干扰（arm64 为 `str/ldr`） | **开**。arm64 上 `stack_confusion` 会让栈回溯变差，崩溃定位困难时关 |
| 10 | BCFOBF | `-enable-bcfobf` | `BCFOBF`/`BCF` | 硬件不透明谓词（CPUID SSE / RDTSC 奇偶 / `CNTPCT_EL0`）、死循环、熵链 | **开**，`probability` 40–60；高于 60 体积与耗时明显跳变 |
| 11 | CSMOBF | `-enable-csmobf` | `CSMOBF`/`CSM` | 混沌状态机（Q32 定点 logistic 映射 + 元胞自动机吸引子 + 模逆解码） | **中档核心**。`nested_dispatch=true` 只给单函数核心算法，否则指数膨胀 |
| 12 | CFFOBF | `-enable-cffobf` | `CFFOBF`/`CFF`/`FLA` | 经典控制流平坦化（无分支代数状态转移），CSM 的兜底 | 与 CSM **二选一**；`mid` 预设走 CFF，`high/max` 走 CSM + 兜底 |
| 13 | VOBF | `-enable-vobf` | `VOBF`/`VEC` | 标量提升到 SIMD 向量空间（128/256/512）+ lane 噪声 + `shufflevector` 置换 | **开**，`width=128`（arm64 只有 NEON） |
| 14 | INDIBRAN | `-enable-indibran` | `INDIBRAN`/`INDIBR` | 跳转目标 Knuth 乘法哈希加密 + 牛顿迭代模逆解码 + 加密跳转表 | **开**。`enc_jump_target=true` 体积涨得快，热路径可关 |
| 15 | FUNCWRA | `-enable-funcwra` | `FUNCWRA`/`FW` | 入口代理 trampoline（`IdentityNoise`/`ArgShuffle`/`RetMask`）+ 强制 `noinline optnone` | **默认关**。`optnone` 会阻断内联与后续优化，热路径慎用 |

预设级开关（同样是 `-mllvm`）：`-enable-lowobf`（别名 `-lowobf`/`-low`）、`-enable-medobf`（`-medobf`）、
`-enable-highobf`（`-highobf`/`-high`）、`-enable-maxobf`（`-maxobf`）、`-enable-allobf`（`-allobf`）；
再加 `-nk`（总闸）、`-nk-preset=<name>`、`-nk-config=<path>`、`-obf-verbose`（env `VERBOSE`/`OBF_VERBOSE`）、
`-obf-trace`（env `TRACE`/`OBF_TRACE`）。

---

## 4. low / mid / high / max 预设对照

| 维度 | `low` | `mid`（默认推荐） | `high` | `max` |
| --- | --- | --- | --- | --- |
| BCF | 30% / 1 轮 / complexity 2，无熵链、无 junk asm | 60% / 1 轮 / c4，无熵链 | 75% / 2 轮 / c6，熵链 + junk asm + `create_func` | 100% / 3 轮 / c8，junk asm 4–8 |
| Sub | 40% / 1 | 60% / 1 | 80% / 2 | 100% / 3 |
| MBA | 30% / 1 层 / 无启发式 | 50% / 2 层 | 70% / 3 层 | 100% / 3 层 |
| StrEnc | 70%，anti_dump | 100%，anti_dump | 100%，anti_dump | 100%，anti_dump |
| ConstEnc | 2-share，无 Feistel | 3-share + Feistel + subxor 40% | 2 轮 / 4-share + subxor 60% + globalize 50% | 3 轮 / 6-share + subxor 100% + globalize 80% |
| Split | 2 刀，无栈干扰 | 3 刀 + 栈干扰 | 5 刀 + 栈干扰 | 8 刀 + 栈干扰 |
| Vec | 关 | 40% / 128-bit / 无 shuffle | 65% / 256-bit / shuffle | 90% / 512-bit / shuffle |
| 平坦化 | 关 | CFF 开，CSM 关 | CSM 开（非嵌套，max_blocks 10000），CFF 关 | CSM 嵌套派发 + warmup 256 + max_blocks 100000，CFF 开 |
| IndirBranch | 关 | 开（enc_jump_target=false） | 开（enc=true） | 开（enc=true） |
| FuncWra / FCO | 关 / 关 | 关 / 关 | 50% 1 轮 / **开** | 100% 2 轮 / **开** |
| AntiHook / AntiDebug / ACD | 关 | 关 / 关 / 关 | 开（ADB 50%） | 开（ADB 100%）/ 开 |
| 体积（经验区间） | ≈1.2–1.5× | ≈2–3× | ≈4–8× | ≈8–20× |
| 编译耗时（经验区间） | ≈1.2× | ≈2–3× | ≈4–6× | ≈8×+ |
| 典型场景 | 调试期、CI 冒烟、热路径模块 | **生产发布、商业 SDK、游戏 .so** | 授权/校验引擎、核心算法 | 红队交付、极限压测 |

kit 的 `config/presets/{low,mid,high,max}.toml` 是「预设 + Android 修正」：`mid` 显式关掉
`anti_debugging`/`anti_hooking`/`function_call_obfuscate` 并把 `vector_obfuscation.width` 钉在 128；
`high` 把 anti_debugging 降到 60% 且仍关 FCO；`max` 打开 FCO 但向量宽度仍是 128（arm64 没有 AVX）。

**arm64 专属提醒**：`vector_obfuscation.width = 256/512` 在 arm64 上没有对应寄存器，会退化成标量模拟
——体积涨、收益降。所有预设与默认配置都把它固定为 128。

---

## 5. 配置示例（完整 TOML）

`$KIT/config/nk.toml` 就是下面这份（Android 取向，偏保守），可直接复制改写：

```toml
[global]
preset = "mid"           # low | mid | high | max | csm_vec | csm_only | vec_only
# seed = "0x1337C0DE"    # 固定种子便于 diff；省略则每次编译随机
verbose = false
trace = false
demangle_names = true

[passes.string_encryption]
enabled = true
probability = 100
anti_dump = true
force_content = [".*secret.*", ".*token.*", ".*license.*", ".*password.*", ".*key.*"]
skip_content  = ["^%[0-9]*[a-zA-Z]$", "^Java_.*", "^JNI_.*"]

[passes.constant_encryption]
enabled = true
iterations = 1
share_count = 3
feistel = true
substitute_xor = true
substitute_xor_prob = 40
globalize = false
globalize_prob = 50
force_value = ["^0x9E3779B9$", "^0x5F3759DF$"]
skip_value  = ["^0x0$", "^0x1$"]

[passes.bcf]
enabled = true
probability = 50          # Android 建议 40–60
iterations = 1
complexity = 4
entropy_chain = true
junk_asm = true
junk_asm_min = 2
junk_asm_max = 6
nested = false
create_func = false
only_junk_asm = false

[passes.substitution]
enabled = true
probability = 50
iterations = 1

[passes.mba]
enabled = true
probability = 45
layers = 2
heuristic = true

[passes.split_blocks]
enabled = true
splits = 3
stack_confusion = true    # 栈回溯异常时可关

[passes.chaos_state_machine]
enabled = true
warmup = 128
nested_dispatch = false
max_blocks = 5000

[passes.flattening]
enabled = false

[passes.vector_obfuscation]
enabled = true
probability = 35
width = 128               # arm64：只有 NEON
shuffle = true
lift_comparisons = true

[passes.indirect_branch]
enabled = true
use_stack = true
enc_jump_target = true

# ── 真机行为敏感，默认全关 ──
[passes.function_wrapper]
enabled = false
probability = 50
times = 1

[passes.function_call_obfuscate]
enabled = false
flag = 0
symbol_config_path = ""

[passes.anti_hooking]
enabled = false
inline_aarch64 = true
direct_syscall = true
check_integrity = true
antirebind = false

[passes.anti_debugging]
enabled = false
probability = 80

# ── 按「模块路径 + 函数名」覆写强度 ──
[[policy]]
module_regex = ".*(crypto|sign|license|auth|verify|vm).*"
function_regex = ".*"
preset = "high"
passes.chaos_state_machine.enabled = true
passes.mba.layers = 3

[[policy]]
module_regex = ".*"
function_regex = "^(JNI_OnLoad|JNI_OnUnload|__aeabi_.*|.*_init|.*_fini)$"
passes.string_encryption.enabled = false
passes.bcf.enabled = false
passes.chaos_state_machine.enabled = false
passes.flattening.enabled = false
passes.indirect_branch.enabled = false
passes.function_wrapper.enabled = false
passes.vector_obfuscation.enabled = false
```

> **默认配置结论（明确写死）**：`config/nk.toml` 中 `anti_debugging`、`anti_hooking`、
> `function_call_obfuscate`、`function_wrapper` 全部 `enabled = false`。要开必须显式改配置或换 `high`/`max`。

### 5.1 `<module_regex>` / `function_regex` 匹配语义

- **引擎**：`std::regex` + `std::regex::ECMAScript`（+ `optimize`）。即 ECMAScript 语法：
  `.*`、`^...$`、`(a|b)`、`[0-9]`、`\d`/`\w`。PCRE 扩展（lookbehind、`\p{...}`、条件组、命名组）不支持，
  用了会抛 `regex_error`；TOML 双引号串里反斜杠要写双份（`"\\d"`、`"\\."`）。
- **匹配方式**：`std::regex_search` —— **子串搜索，不是整串匹配**。所以 `module_regex = "crypto"` 等价于
  `".*crypto.*"`；要精确限定必须自己写 `^...$`。
- **匹配对象**：
  - `module_regex` → 该 TU 的**源文件路径**（`Module::getSourceFileName()`，即编译时的 `crypto/aes.c` 这类相对/绝对路径）。
  - `function_regex` → 函数**原始 mangled 名**，同时再试一次 **demangle 后**的名字（所以 C++/Rust 可以写人话正则）。
- **求值顺序**：策略表按书写顺序求值，**首个命中即生效并作为该函数的基线**（`preset` 先铺底，随后本条的
  `passes.*` 覆盖）；实现上多条同时命中会按顺序合并、后条覆盖同名字段。因此：**把最强规则写在前面，
  并保证规则互斥**，不要依赖「后面的规则能兜住前面的」。
- **未写 `module_regex`/`function_regex` 的字段视为「不限」**；策略解析失败（正则非法）会在 stderr 打
  `[Nk] invalid ... regex in policy` 并跳过该条。
- 实际生效参数优先级仍然是：源码注解 > 命中策略的 `passes.*` > 策略 `preset` > 全局 `[passes.*]` > `[global] preset`。

### 5.2 `force_content` / `skip_content` / `force_value`

| 字段 | 作用对象 | 匹配串 | 语义 |
| --- | --- | --- | --- |
| `skip_content` | 字符串全局变量（`i8` 字符数组的字面量） | 字符串**内容原文** | 命中即把该串的加密概率置 0（**先判 skip**，skip 优先于 force） |
| `force_content` | 同上 | 同上 | 命中即把该串概率置 100，忽略 `probability` |
| `skip_value` | `ConstantInt` | 规范化的十六进制串，如 `0x9E3779B9`（大写、无前导 0） | 命中返回 -1：跳过 |
| `force_value` | 同上 | 同上，**大小写不敏感** | 命中返回 +1：强制加密 |

用法要点：

- `skip_content` 至少要挡住两类：`printf` 格式串（`^%[0-9]*[a-zA-Z]$` 这类短格式）和 **JNI 符号名**
  （`^Java_.*`、`^JNI_.*`）——后者被加密会导致 `RegisterNatives`/`dlsym` 找不到入口。
- `force_content` 用来打「名字看着像密钥」的串，但注意它是**子串正则**：`.*key.*` 会误伤 `keyboard`、`monkey`。
  精确打击请自己锚定（如 `^\\.key$`、`key=.*`）；引擎无大小写内联开关，需要时把大小写都列进数组。
- `force_value` 的正则作用在 `toString(16).upper()` 结果上：比较 `0x1` 要写 `^0x1$`，否则 `^0x1` 会命中 `0x1F`。
- 字符串加密只覆盖 `i8` 数组；宽字符/`ConstantDataArray<i32>` 不会被 `force_content` 捞到。

---

## 6. 构建系统集成

两种接法，任选其一（不要同时用，否则插件被加载一次、参数叠两次）：

- **接法 ①（推荐）环境变量继承**：设置 `NK=1 NK_PRESET=… NK_CONFIG=…`，让构建系统照常调用
  `$PRE/bin/<triple>-clang`，包装器自己插 `-fpass-plugin`。
- **接法 ② 显式参数**：直接写 `-fpass-plugin=$KIT/lib/libNk.so` + `-mllvm -nk-config=<toml>`，不依赖包装器与环境（CI 里更可控）。
  注意此时总闸需要 `-mllvm -nk`（或显式 `-mllvm -nk-preset=mid`），否则 `EnableIRObfusaction` 不置位。

### 6.1 ndk-build

```make
# jni/Application.mk
APP_ABI := arm64-v8a
APP_PLATFORM := android-26
APP_STL := c++_static
```

```bash
# 接法 ①：shell 里开混淆，ndk-build 继承环境
export NDK=/opt/android-ndk-r29
. $NDK/toolchains/llvm/prebuilt/linux-arm64/nk/bin/nk-env.sh mid
$NDK/ndk-build -j"$(nproc)" APP_ABI=arm64-v8a
```

```make
# jni/Android.mk —— 接法 ②：显式参数（不依赖环境继承）
LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE    := native-lib
LOCAL_SRC_FILES := native-lib.c crypto/aes.c
NK_DIR := $(NDK_ROOT)/toolchains/llvm/prebuilt/linux-arm64/nk
LOCAL_CFLAGS  += -O2 \
  -fpass-plugin=$(NK_DIR)/lib/libNk.so \
  -mllvm -nk -mllvm -nk-config=$(NK_DIR)/config/nk.toml
LOCAL_LDFLAGS += -Wl,--gc-sections
include $(BUILD_SHARED_LIBRARY)
```

### 6.2 CMake（android.toolchain.cmake）

```bash
# 接法 ①：环境继承
export NDK=/opt/android-ndk-r29
PRE=$NDK/toolchains/llvm/prebuilt/linux-arm64
. $PRE/nk/bin/nk-env.sh mid
cmake -S . -B build-arm64 -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE=$NDK/build/cmake/android.toolchain.cmake \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 \
  -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
cmake --build build-arm64
```

```cmake
# CMakeLists.txt —— 接法 ②：显式参数（推荐给 CI，不依赖 daemon 环境）
set(NK_DIR "$ENV{NDK}/toolchains/llvm/prebuilt/linux-arm64/nk")
set(NK_PLUGIN "${NK_DIR}/lib/libNk.so")
set(NK_TOML   "${NK_DIR}/config/nk.toml")

add_library(native-lib SHARED native-lib.c crypto/aes.c)
target_compile_options(native-lib PRIVATE
  -O2
  -fpass-plugin=${NK_PLUGIN}
  -mllvm -nk
  -mllvm -nk-config=${NK_TOML}
  -fvisibility=hidden
  -ffunction-sections -fdata-sections)
target_link_options(native-lib PRIVATE -Wl,--gc-sections)
```

`-mllvm` 是 driver 选项，`target_compile_options` 里逐个 token 写（不要拼成一个字符串，否则 `-mllvm`
和它的值会被合并）。切换 `NK=` 开关后必须重新配置（见 TROUBLESHOOTING 的 CMake 缓存条目）。

### 6.3 Gradle `externalNativeBuild`

```groovy
android {
    ndkVersion "29.0.14206865"
    defaultConfig {
        minSdk 26
        ndk { abiFilters "arm64-v8a" }
        externalNativeBuild {
            cmake {
                // 接法 ②：参数显式落地，Gradle daemon 环境不必继承 NK
                arguments "-DANDROID_STL=c++_static",
                          "-DANDROID_PLATFORM=android-26"
                cppFlags "-O2", "-fvisibility=hidden"
                cFlags   "-O2", "-fvisibility=hidden"
            }
        }
    }
    externalNativeBuild { cmake { path file("src/main/cpp/CMakeLists.txt") } }
}
```

```groovy
// 接法 ①：沿用环境变量继承，注意 Gradle daemon 会缓存环境
// shell: export NK=1 NK_PRESET=mid NK_CONFIG=$KIT/config/nk.toml
// 然后必须重启 daemon，否则拿的是旧环境：
//   ./gradlew --stop && ./gradlew assembleRelease
```

Gradle 侧不要用 `cFlags` 拼 `-fpass-plugin=` 再加 `-mllvm` 到同一个字符串里；`cFlags` 会把整串当一个
token 传给编译器。参数多时统一走 CMake 的 `target_compile_options`。

---

## 7. JNI / Android 注意事项

1. **不要改写 `Java_*` / `JNI_*` 符号**。`FeatureElimination` 阶段会 internalize 私有符号、把名字打成
   `_f<hex>`/`_v<hex>`，JNI 导出名一旦被改写，`RegisterNatives` 与 `dlsym("Java_x_y_z")` 直接失败。
   做法：`-fvisibility=hidden` + `JNIEXPORT`/`__attribute__((visibility("default")))`，并在配置里把
   `skip_content` 保留 `^Java_.*`/`^JNI_.*`，函数级用 policy 把 `JNI_OnLoad`/`JNI_OnUnload` 的
   `string_encryption`/`bcf`/`csm`/`flattening`/`indirect_branch`/`function_wrapper`/`vector_obfuscation` 关掉
   （见第 5 节示例的第二条 policy）。
2. **条带化与 anti_dump**。`string_encryption.anti_dump = true` 会在函数返回/恢复路径把解密后的明文清零，
   并剥掉内存 dump 标记；发布包再叠加 `llvm-strip --strip-unneeded`（去掉 `.symtab`/`.debug_*`）。
   顺序必须是「先混淆编译、后 strip」，不要先 strip 再混淆。注意 `llvm-strip` 不要删掉 `.dynsym`
   （那是 JNI 导出与 `dlsym` 依赖的唯一来源）。
3. **`-O0` / `optnone`**。多个 pass（BCF/CSM/CFF/Vec）依赖优化后的 IR，`-O0` 下效果显著变差；而
   `function_wrapper` 会强制给被包裹函数打 `noinline + optnone`，后续 pass 与 LTO 都会跳过它们。
   结论：发布构建固定 `-O2`（`-O3` 也可以，但先把体积基准测出来），调试构建干脆 `NK=0`。
4. **LTO**。插件注册了 `registerOptimizerLastEPCallback` 与 `registerFullLinkTimeOptimizationLastEPCallback`，
   并显式跳过 `ThinLTOPreLink`/`FullLTOPreLink` 阶段。所以走 LTO 时请用**全量 LTO**（`-flto` + `-fuse-ld=lld`），
   ThinLTO 的 prelink 阶段不会执行混淆。LTO 与 `function_wrapper` 的 `optnone` 冲突：被包裹的函数不会被 LTO 优化，
   体积会明显变大，二选一。
5. **单 .so 多模块策略**。`module_regex` 匹配的是每个 TU 的源文件路径，所以「模块」= 源文件所在路径。
   想让 `crypto/*` 走 `high`、`ui/*` 走 `low`，就把源码按目录切开（`crypto/`、`sign/`、`license/`、`auth/`、
   `verify/`、`vm/`），policy 才能命中。同一个 .so 内混用不同预设是支持的，但要注意：
   跨 TU 内联会让策略边界变模糊（`static inline` 函数跟随调用者 TU 的配置），关键函数建议
   `__attribute__((noinline))` 落到自己的 TU。
6. **ABI 分级**。只有 `arm64-v8a` 是 Tier 0；`armeabi-v7a`/`x86`/`x86_64` 属尽力而为，
   arm32 上 VOBF/CSM 的收益与稳定性都会下降，`x86` 上 anti_hook 的 inline 探测逻辑与 arm64 不同。
   发布包建议只带 `arm64-v8a`，或对其它 ABI 单独降档（`mid` 或 `low`）。

---

## 8. 验证

### 8.1 一键对照实验

```bash
$KIT/bin/verify.sh --api 26 --abi arm64-v8a --preset mid
# 做了什么：
#   1) 环境自检：per-API 包装器、真实 clang、libNk.so、.plugin-capable、clang 的 .dynsym
#   2) 同一份 samples/hello.c 编两遍：NK=0 基线 / NK=1 混淆
#   3) 断言：体积增大、明文 NK_SECRET_TOKEN 消失、符号表变化
# 保留中间产物做手工比对：
$KIT/bin/verify.sh --preset high --keep
```

### 8.2 手工核对（逐条命令）

```bash
# 插件本身：入口符号 + ELF 架构
llvm-readelf -h  $KIT/lib/libNk.so | grep -E 'Class|Machine|Type'
llvm-nm -D --defined-only $KIT/lib/libNk.so | grep llvmGetPassPluginInfo

# 编译器能力：.dynsym 里必须能看到 LLVM 符号，否则插件无从解析
llvm-readelf --dyn-syms -W $PRE/bin/clang-21 | grep -c PassBuilder
$KIT/bin/install-plugin.sh --check          # 等价封装，退出码 0 = 可加载

# 混淆开关是否真的注入了：看驱动命令行
NK=1 NK_PRESET=mid $CC26 -### -O2 -shared -fPIC demo.c 2>&1 | grep -o 'fpass-plugin=[^ "]*'

# 产物体积对照
NK=0 $CC26 -O2 -shared -fPIC -o /tmp/plain.so demo.c; stat -c '%s %n' /tmp/plain.so
NK=1 NK_PRESET=mid $CC26 -O2 -shared -fPIC -o /tmp/obf.so demo.c; stat -c '%s %n' /tmp/obf.so

# 明文与符号
strings -a /tmp/obf.so | grep -c 'NK_SECRET_TOKEN'      # 期望 0
llvm-nm -D --defined-only /tmp/obf.so | head               # 只应剩 JNI/对外导出
llvm-nm -a /tmp/obf.so | wc -l                             # 与基线比应显著变化

# 段与重定位（确认没有残留导入、跳转表形态变化）
llvm-readelf -d /tmp/obf.so | grep NEEDED
llvm-readelf -S /tmp/obf.so | grep -E '\.text|\.rodata'
```

### 8.3 回归基线建议

每次改配置后固定三项数字，写进 CI 断言：`.so` 字节数、`N NEEDED` 库数量、`strings | grep -c <密钥串>`。
再补一条真机冒烟：安装后 `adb logcat -s AndroidRuntime` 无 `FATAL EXCEPTION`，且 JNI 入口全部可调。
