# Ensia (OLLVM-Next) × Android NDK r29 (linux-arm64 prebuilt)

本目录是集成套件（kit），位于：

```
<ndk>/toolchains/llvm/prebuilt/linux-arm64/ensia/
```

同时 NDK 的入口 `bin/clang` 已从「指向 clang-21 的软链接」替换为 **Ensia 注入包装器**
（`bin/clang-21` 仍是原始编译器二进制，`bin/clang++` 仍是 `clang` 的软链接）。

- 上游：<https://github.com/Apich-Organization/ensia>（AGPL-3.0）
- 本 kit 内置源码快照 commit：`56a6df148c45fd7d2afa7cd4976d7d8d88075c8e`
- NDK：`29.0.14206865 (r29)`，clang `21.0.0 (based on r563880c)`

---

## 0. 先理解一个硬事实

这个 NDK 的 `bin/clang-21` 是 **静态链接、非 PIE、没有 `.dynsym` / `.dynamic`** 的 aarch64
可执行文件（Android `dev` 构建，`+lto +pgo`）：

```
ELF type: EXEC (非 PIE)   .interp: 无   .dynsym: 无
```

clang 加载 `-fpass-plugin=` 需要在进程内 `dlopen` 并解析 LLVM 符号；静态可执行文件既没有动态
符号表，也无法可靠 `dlopen`。所以 **直接往原版 clang 上挂插件一定失败**（表现为
`unable to load plugin ... undefined symbol`）。

因此本 kit 提供两条真正可用的路线：

| 路线 | 做法 | 需要什么 | 适用 |
| --- | --- | --- | --- |
| **A（推荐、成品化）** | 重编 clang-21：`LLVM_ENABLE_PLUGINS=ON` + `LLVM_EXPORT_SYMBOLS_FOR_PLUGINS=ON`，让 clang 导出 LLVM 符号，再加载 ensia 插件 | 一台 Linux x86_64/aarch64 构建机（≥8 核 / ≥16 GB 内存 / ≥40 GB 磁盘）或 GitHub Actions | 想要「NDK 原生 `clang` 直接带混淆」 |
| **B（零重编、当天可用）** | 用外部「能加载插件」的 clang 21（Termux 的 `llvm` 包、自编 LLVM 21 等）当交叉编译器，套 NDK sysroot | 设备上装 Termux `llvm` + `cmake` + `ninja` | 想在手机上直接编译混淆 .so |

两条路线共用同一个插件产物 `ensia/lib/libEnsia.so` 与同一套配置/预设。

---

## 1. 目录结构

```
ensia/
├── README.md                  ← 本文件（总览）
├── VERSION                    ← kit / 上游 / NDK 版本锚点
├── bin/
│   ├── build-clang.sh         ← 路线 A：重编导出符号的 clang + 编插件（一条命令）
│   ├── build-plugin.sh        ← 只编插件（交叉或本机）
│   ├── install-plugin.sh      ← 安装插件 + 校验 clang 能力 + 写 .plugin-capable
│   ├── verify.sh              ← 混淆效果对照实验（自检）
│   ├── ensia-status.sh        ← 状态总览（版本/插件/能力/下一步）
│   ├── ensia-env.sh           ← source 一下即开启（ndk-build / CMake / Gradle 通用）
│   └── ensia-clang            ← 路线 B：外部插件版 clang 驱动
├── config/
│   ├── ensia.toml             ← Android 取向默认配置（anti_debug / antihook / fco 默认关）
│   └── presets/{low,mid,high,max}.toml
├── docs/
│   ├── INTEGRATION.md         ← 集成原理与构建细节、回滚、CI
│   ├── USAGE.md               ← 开关/预设/15 pass/构建系统集成
│   └── TROUBLESHOOTING.md     ← 现象→原因→处理
├── lib/                       ← 插件落地目录（libEnsia.so + .plugin-capable）
├── samples/hello.c            ← 验证样本
├── src/                       ← ensia 源码快照（obfuscation/ compat/ test/）
└── ci/build-ensia-ndk.yml     ← GitHub Actions：产出 clang-21 + libEnsia.so
```

---

## 2. 快速开始

### 路线 A：重编 clang（一次性，之后 NDK 原生可用）

在 Linux 构建机上（**不能**在 Windows 上做：目标 clang 是 aarch64 Linux 程序）：

```bash
# 建议用官方完整 NDK r29（含 linux-x86_64 prebuilt 作为交叉工具链）
export NDK=/opt/android-ndk-r29

# 把本 kit 装进「目标」prebuilt（linux-arm64）目录后再执行：
#   cp -r ensia-ndk/ensia   $NDK/toolchains/llvm/prebuilt/linux-arm64/ensia
#   cp ensia-ndk/clang      $NDK/toolchains/llvm/prebuilt/linux-arm64/bin/clang   (先删软链接)
KIT=$NDK/toolchains/llvm/prebuilt/linux-arm64/ensia

$KIT/bin/build-clang.sh --ndk "$NDK" --work ~/ensia-llvm --jobs "$(nproc)"
# 编译完成后会自动：装 clang-21（原文件备份 clang-21.bak）→ 编插件 → 写 .plugin-capable

$KIT/bin/verify.sh          # 对照实验：体积/明文字符串/符号表
. $KIT/bin/ensia-env.sh mid # 之后 normal 编译即带混淆
```

编译产物（`ENSIA=1` 时生效）：

```bash
ENSIA=1 ENSIA_PRESET=mid \
  $NDK/toolchains/llvm/prebuilt/linux-arm64/bin/aarch64-linux-android26-clang \
  -O2 -shared -fPIC -o libdemo.so demo.c
```

### 路线 B：Termux（手机上，不重编 clang）

```bash
pkg install llvm cmake ninja git          # Termux：llvm 21，动态链接 libLLVM，支持插件
KIT=/path/to/ndk/toolchains/llvm/prebuilt/linux-arm64/ensia

# 1) 本机编插件（走 aarch64 native，用 Termux 的 LLVM 21）
$KIT/bin/build-plugin.sh --llvm-dir "$(llvm-config --cmakedir)/../../.."

# 2) 用外部 clang 交叉编译你的源码
$KIT/bin/ensia-clang --abi arm64-v8a --api 26 --preset mid \
  -O2 -shared -fPIC -o libdemo.so demo.c
```

注意：路线 B 的插件必须与 Termux 的 LLVM **同版本**（21.x），否则加载即崩。

---

## 3. 开关（一句话版）

| 变量 | 作用 |
| --- | --- |
| `ENSIA=1` | 打开注入；不设=完全透传，等价原版 clang |
| `ENSIA_PRESET=low\|mid\|high\|max` | 强度预设（透传给插件） |
| `ENSIA_CONFIG=/path/ensia.toml` | 指定配置；不设则用 `config/ensia.toml` |
| `ENSIA_REAL_CLANG=/path/clang` | 指定真实编译器（默认 `bin/clang-21`） |
| `ENSIA_FORCE=1` | 忽略 `.plugin-capable` 能力标记 |

关闭：`unset ENSIA`，或 `rm ensia/lib/.plugin-capable`，或 `. ensia/bin/ensia-env.sh off`。

---

## 4. 回滚

```bash
PRE=<ndk>/toolchains/llvm/prebuilt/linux-arm64
cp -f $PRE/bin/clang-21.bak $PRE/bin/clang-21     # 还原原版编译器
rm -f  $PRE/ensia/lib/.plugin-capable             # 包装器回到透传
# 彻底恢复原状：把 bin/clang 恢复成软链接
ln -sfn clang-21 $PRE/bin/clang
```

---

## 5. 文档

- 用法、15 个 pass、预设、CMake/ndk-build/Gradle 接线 → [docs/USAGE.md](docs/USAGE.md)
- 老 OLLVM 参数（`-bcf/-fla/-sub/-sobf/...`）→ Ensia 开关的 Android.mk 对照表 → [docs/LEGACY-OLLVM-FLAGS.md](docs/LEGACY-OLLVM-FLAGS.md)
- **全部功能说明（15 个 pass + 26 个开关 + 34 个别名 + 95 个环境变量 + 策略系统）** → [docs/功能总览.txt](docs/功能总览.txt)
- 集成原理、构建细节、CI、离线分发 → [docs/INTEGRATION.md](docs/INTEGRATION.md)
- 报错与处理 → [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)

## 6. 许可

ensia 上游为 **AGPL-3.0**，源码位于 `src/`；商用/分发请遵守其条款（见 `src/LICENSE`、`src/LEGAL.md`）。
