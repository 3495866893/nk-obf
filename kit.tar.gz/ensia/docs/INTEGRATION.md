# 集成原理与构建细节

本文说明这套集成到底改了什么、为什么这么改，以及在 Linux 构建机上如何一步步产出可用产物。

---

## 1. 集成点：只改一个入口

NDK 的编译链路（r29，linux-arm64）是：

```
用户/构建系统
   └─ bin/aarch64-linux-android26-clang        (201B bash 脚本, 加 --target=...)
        └─ bin/clang                          (原本是指向 clang-21 的软链接)
             └─ bin/clang-21                  (78 MB 静态 aarch64 可执行文件)
   └─ bin/clang++ ───────────────────────────► bin/clang   (软链接链, 但 basename 带 "++")
```

所有 per-API 包装脚本（`aarch64-linux-androidNN-clang`、`armv7a-...`、`i686-...`、`x86_64-...`，
共 100+ 个）最终都调用 `$bin_dir/clang`，所以：

> **只把 `bin/clang` 换成包装器，就能覆盖全部 ABI/API 入口，同时不改动 NDK 的任何原有脚本。**

包装器（同包内 `clang` 文件）的行为：

1. `bin/clang++` 软链接过来时，`$0` 的 basename 含 `++` → 自动补 `--driver-mode=g++`，C++ 模式不丢；
2. `$1` 为 `-cc1` / `-cc1as` / `--version` / `--print-*` 等内部或查询调用时**不注入**
   （`-fpass-plugin` 是 driver 级选项，cc1 不接受，注入会导致编译失败）；
3. 仅当 `ENSIA=1` 且存在 `lib/libEnsia.so` 且存在 `.plugin-capable` 时才追加
   `-fpass-plugin=<abs path>` 并把 `ENSIA_CONFIG` 默认指向 `config/ensia.toml`；
4. 其余情况 `exec clang-21 "$@"`，**零开销透传**（只是多一次 shell exec）。

`.plugin-capable` 标记的意义：避免「clang 还是原版静态版」时盲目注入导致每个编译单元都报
`unable to load plugin`。标记由 `bin/install-plugin.sh` 在校验 clang 动态符号后写入。

---

## 2. 路线 A：为什么必须重编 clang

`bin/clang-21` 的 ELF 事实：

| 项 | 值 | 含义 |
| --- | --- | --- |
| `e_type` | `EXEC`（非 PIE） | 不是动态可执行 |
| `.interp` | 不存在 | 没有动态加载器参与 |
| `.dynsym` / `.dynstr` / `.dynamic` | 不存在 | **进程内没有动态符号表** |
| 构建串 | `Android (dev, +pgo, -bolt, +lto, -mlgo, based on r563880c)`，`LLVM 21.0.0` | 上游 21.0.0 定制 |

LLVM 的 `-fpass-plugin` 走 `llvm::sys::DynamicLibrary::LoadLibraryPermanently` → `dlopen`，然后
`dlsym("llvmGetPassPluginInfo")`；插件里未定义的 LLVM 符号由**宿主进程**提供。静态宿主动态
符号表为空 → 插件里的 `_ZN4llvm...` 全部解析失败。

所以路线 A 用 `build-clang.sh` 干这件事：

```
llvm-project @ llvmorg-21.0.0   (与 NDK clang 的 LLVM 21.0.0 对齐)
   ├─ 先编 host 版 llvm-tblgen / clang-tblgen（交叉编译必需）
   └─ 交叉配置目标 aarch64-linux-android<API>，关键开关：
        -DLLVM_ENABLE_PLUGINS=ON
        -DLLVM_EXPORT_SYMBOLS_FOR_PLUGINS=ON     ← 给可执行加 --export-dynamic
        -DANDROID_STL=c++_static                  ← 不依赖 libc++_shared
        -DLLVM_ENABLE_PROJECTS="clang;lld"
        -DLLVM_TARGETS_TO_BUILD="AArch64;ARM;X86"
        -DLLVM_PARALLEL_LINK_JOBS=1               ← 防止链接期 OOM
```

产出 `clang` 覆盖 `bin/clang-21`（先备份 `clang-21.bak`），然后：

- `lib/clang/21/…`（内建头文件）继续复用 NDK 原有的，因为版本号仍是 21；
- `../sysroot` 继续可被自动发现（同在 `prebuilt/linux-arm64/` 布局下）；
- 再以**同一棵构建树**的 `lib/cmake/llvm` 为 `LLVM_DIR` 交叉编译 ensia 插件
  （头文件与 ABI 与运行中的 clang 完全一致，这是避免「插件加载后崩在 IR 校验」的关键）。

### 构建机要求

| 项 | 要求 |
| --- | --- |
| OS | Linux x86_64（推荐）或 Linux aarch64；**Windows 不可**（产不出 aarch64 ELF） |
| CPU/RAM | ≥ 8 核 / ≥ 16 GB（16 核 32 GB 约 40–70 分钟） |
| 磁盘 | ≥ 40 GB（源码 1.5 GB + 构建树 25–35 GB + 安装） |
| 依赖 | `cmake>=3.28`、`ninja`、`git`、`python3`、`zlib` 开发包 |
| NDK | 完整 NDK r29（需要 host 对应的 `linux-x86_64` prebuilt 当交叉工具链） |

`--out-dir` 模式可以把 `clang-21` 与 `libEnsia.so` 输出到任意目录（CI 用），由你自行塞回目标 NDK：

```bash
PRE=<ndk>/toolchains/llvm/prebuilt/linux-arm64
cp clang-21    $PRE/bin/clang-21
cp libEnsia.so $PRE/ensia/lib/libEnsia.so
date >         $PRE/ensia/lib/.plugin-capable
```

---

## 3. 路线 B：外部插件版 clang + NDK sysroot

不需要重编：任何「动态链接 libLLVM 且导出符号」的 clang 21 都能加载插件（Termux 的 `llvm`
包、自编 LLVM 21、发行版 clang-21）。`bin/ensia-clang` 负责补齐 NDK 交叉编译必需参数：

```
<clang> --target=aarch64-linux-android26 --sysroot=<prebuilt>/sysroot -fpass-plugin=<lib>
```

它不做 NDK 的资源目录注入，所以**内建头文件来自外部 clang 自己的 resource dir**（版本 21 即可）。
C++ 场景请确保外部 clang 能找到 `<sysroot>/usr/include/c++/v1`（Termux 的 clang 默认即可）。

局限：
- 二进制/库的链接器来自外部 clang 安装（Termux 自带 `ld.lld`）；
- `--target=armv7a-linux-androideabi` 需要外部 clang 有 ARM 后端（Termux 构建通常含）。

---

## 4. 校验清单

```bash
PRE=<ndk>/toolchains/llvm/prebuilt/linux-arm64

# 1) 新 clang 是否导出 LLVM 符号
readelf --dyn-syms -W $PRE/bin/clang-21 | grep -c PassBuilder      # 期望 > 0

# 2) 插件入口
readelf -h $PRE/ensia/lib/libEnsia.so | grep Machine               # AArch64
nm -D --defined-only $PRE/ensia/lib/libEnsia.so | grep llvmGetPassPluginInfo

# 3) 端到端
$PRE/ensia/bin/verify.sh --preset low
```

`verify.sh` 做三组断言：体积增大、明文 token 消失、符号表变化；任一项失败会给出原因。

---

## 5. CI 与离线分发

`ci/build-ensia-ndk.yml`：在 ubuntu-22.04 上下载官方 NDK r29 → 装 kit → `build-clang.sh
--out-dir artifacts` → 上传 `clang-21` / `libEnsia.so` / `ensia-dropin.zip`。

- 默认 runner 4 核 14 GB 空闲（已用 `free-disk-space` 腾到 ~30 GB），LLVM 构建约 4–6 小时，
  有超时风险；建议自托管 8 核/32 GB。
- 产物落地方式见上一节。

---

## 6. 关于重打包 NDK 压缩包

原 tarball 里有 663 个软链接与 364 个硬链接（`bin/clang`、`bin/clang++`、`bin/lld` 等）。
任何「先解压到 Windows 再压回去」的做法都会丢软链接（Windows 默认不允许普通用户创建 symlink）。
本 kit 的封装方式是 **在 tar 层原地重写**：用 Python `tarfile` 逐成员拷贝原包，仅替换
`android-ndk-aide/toolchains/llvm/prebuilt/linux-arm64/bin/clang`（软链接 → 包装脚本），并追加
`android-ndk-aide/toolchains/llvm/prebuilt/linux-arm64/ensia/**`，其余成员（含 hardlink、权限位、
mtime）原样保留。

重打包脚本见交付目录的 `repack_ensia_ndk.py`（可用 `--help` 查看参数）。

---

## 7. 体积与性能预期

| 项 | 原版 | 路线 A 重编后 |
| --- | --- | --- |
| `bin/clang-21` | 78 MB（+lto +pgo） | 约 150–260 MB（无 PGO/BOLT；加 `--lto` 可减小） |
| 冷启动 | 快 | 略慢（无 PGO） |
| 首次编译 | — | 插件加载 + 混淆，编译时间约 ×1.5–3（视预设） |

混淆产物本身：`low` 约 +20–60%，`mid` 约 +2–4×，`high/max` 可到 +5–10×。
