// ===== ENSIASHORTFLAGS-BEGIN: ensia-ndk 补充短名（可选补丁） =====
// 上游 ensia 已经自带一批 OLLVM 兼容别名（sub/fla/bcf/split/sobf/strenc/constenc/
// indibran/indibr/funcwra/fw/csm/mba/vobf/vec/fco/antihook/adb/acd/allobf/
// lowobf/highobf/high/low/medobf/maxobf）。
// 本补丁只补 4 个缺失的顺口短名，名字均为上游未占用：
//   -mid          = -enable-medobf
//   -max          = -enable-maxobf
//   -ibr          = -enable-indibran
//   -ollvm_print  = -obf-verbose
// 回滚：ensia/bin/apply-short-flags.sh --revert
static cl::alias MidAlias2("mid", cl::desc("Alias for -enable-medobf"),
                           cl::aliasopt(EnableMedObfuscation));
static cl::alias MaxAlias2("max", cl::desc("Alias for -enable-maxobf"),
                           cl::aliasopt(EnableMaxObfuscation));
static cl::alias IbrAlias2("ibr", cl::desc("Alias for -enable-indibran"),
                           cl::aliasopt(EnableIndirectBranching));
static cl::alias OllvmPrintAlias("ollvm_print", cl::desc("Alias for -obf-verbose"),
                                 cl::aliasopt(EnableObfVerbose));
// ===== ENSIASHORTFLAGS-END =====
