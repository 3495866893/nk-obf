Ensia × AIDE 一键安装说明
============================================================

为什么不能「装上 NDK 就自动可用」？
----------------------------------------
插件必须与运行它的 clang 同版本、同构建树编出来；NDK 自带 clang 是静态链接、
不能 dlopen 插件。所以「可加载插件的 clang-21 + libEnsia.so」这一对二进制
必须在电脑（或 GitHub Actions）上编一次，任何预编译二进制都不能通用。
除此之外的全部步骤，都由本目录的 install.sh 自动完成。

------------------------------------------------------------
第 1 步（电脑，只需一次）
------------------------------------------------------------
  cd ensia/oneclick
  bash pc-build-dropin.sh
  # 自动：下载官方 NDK r29 → 放 kit → 编译 clang+插件 → 产出 ensia-dropin.tar.gz
  # 依赖：curl unzip git cmake ninja python3，磁盘 ≥40GB，内存 ≥16GB

  没有 Linux？把 ensia/ci/build-ensia-ndk.yml 放进 GitHub 仓库跑 Actions，
  下载 artifact 里的 clang-21 + libEnsia.so，自己 tar 成包也行。

把 ensia-dropin.tar.gz 传到手机，例如 /sdcard/ensia-dropin.tar.gz


------------------------------------------------------------
没有 Linux 电脑？
------------------------------------------------------------
  用 GitHub Actions（免费 4 核 / 16 GB 内存）：
    oneclick/actions/推送与运行.txt    ← 照着做，点鼠标即可
    oneclick/actions/build-ensia-ndk.yml
  跑完下载 ensia-dropin.tar.gz，再执行上面的第 2 步。

------------------------------------------------------------
第 2 步（手机，一条命令）
------------------------------------------------------------
AIDE 内置终端（需能写 AIDE 私有目录 → 通常要 root）：

  cd /path/to/ensia/oneclick          # 或任意路径下的这份脚本
  sh install.sh --dropin /sdcard/ensia-dropin.tar.gz --jni /sdcard/你的工程/jni

它会自动：
  * 找到 AIDE 的 NDK（/data/user/0/ru.factorcode.aidepro/no_backup/ndksupport-*/android-ndk-aide）
  * 补建解包时丢失的 bin/clang++ 软链接、修权限（755/700）
  * 备份并装入新 clang-21（原版 → clang-21.orig.bak）
  * 装入 libEnsia.so 并写 .plugin-capable
  * 给 jni/Android.mk 插入 Ensia 段（放在 include $(BUILD_...) 之前）
  * 给 jni/Application.mk 追加 export ENSIA=1 / ENSIA_PRESET=max / ENSIA_CONFIG=...
    （插件不完整时自动写 ENSIA=0，工程照常能编）
  * 打印自检结论

然后 AIDE：Build → Clean Project → Run。

------------------------------------------------------------
常用
------------------------------------------------------------
  sh install.sh --check                    # 只自检
  sh install.sh --revert --jni <jni 目录>  # 撤销（还原 mk、恢复原 clang-21）
  sh install.sh --ndk <NDK 目录> ...       # 手动指定 NDK 位置

------------------------------------------------------------
出问题
------------------------------------------------------------
* 报 permission denied      → 目录在 AIDE 私有区，需要 root（su -c 'sh install.sh ...'）
* 报 no such file: unzip    → 用 .tar.gz 形式的 dropin（本脚本默认就产 tar.gz）
* 混淆没生效（体积没变）    → 先 sh install.sh --check，看 libEnsia.so 与 .plugin-capable
* 安装后闪退                → 编辑 ensia/config/presets/max-all.toml：
                              passes.function_call_obfuscate.enabled = false（最常见）
                              passes.anti_debugging.enabled = false
* AIDE 重装/重建 NDK 换目录 → 重新跑一次第 2 步
