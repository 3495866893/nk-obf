#!/usr/bin/env bash
# =============================================================================
# build-plugin-android-cross.sh —— 在 x86_64 Linux 上交叉编出 aarch64 的 libEnsia.so
# -----------------------------------------------------------------------------
# 适用场景：你手上有一个「能加载 pass plugin」的 Android clang（比如
#   TUSI-Ollvm-ndk-r29-aide 那个 clang-21：已核实导出 19,572 个 llvm:: 符号、
#   69 个 PassBuilder，并支持 -fpass-plugin），但缺 libEnsia.so。
#   这时**不需要重编 clang**，只要编插件（几分钟、不吃内存）。
#
# 前提（x86_64 Ubuntu 22.04+ / WSL 都行，普通 4–8 GB 内存足够）：
#   * llvm-21 开发文件（只要头文件）：sudo bash -c "$(wget -O - https://apt.llvm.org/llvm.sh)" llvm.sh 21
#     （或 apt install clang-21 llvm-21-dev）
#   * 一个 Android NDK 的 sysroot（用你手机上那份 NDK 的 sysroot 也行，纯目标文件）
#   * 本脚本 + ensia 源码目录（kit/ensia/src）
#
# 用法：
#   ./build-plugin-android-cross.sh --sysroot <NDK>/toolchains/llvm/prebuilt/*/sysroot \
#       [--src <kit>/ensia/src] [--out libEnsia.so] [--api 21] [--jobs 4]
# =============================================================================
set -euo pipefail

HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
SRC="${SRC:-}"
SYSROOT="${SYSROOT:-}"
OUT="${OUT:-$HERE/libEnsia.so}"
API=21
JOBS=$(( $(nproc) > 4 ? 4 : $(nproc) ))
CLANG=""

log() { printf '[plugin-android] %s\n' "$*"; }
die() { printf '[plugin-android] 错误: %s\n' "$*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --src) SRC="$2"; shift 2 ;;
    --sysroot) SYSROOT="$2"; shift 2 ;;
    --out) OUT="$2"; shift 2 ;;
    --api) API="$2"; shift 2 ;;
    --jobs) JOBS="$2"; shift 2 ;;
    --clang) CLANG="$2"; shift 2 ;;
    -h|--help) sed -n '2,26p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) die "未知参数: $1" ;;
  esac
done

# 源码目录：默认向上找 kit/ensia/src
if [ -z "$SRC" ]; then
  for cand in "$HERE/../kit/ensia/src" "$HERE/../ensia/src" "$HERE/../src"; do
    [ -d "$cand/obfuscation" ] && { SRC=$cand; break; }
  done
fi
[ -n "$SRC" ] && [ -d "$SRC/obfuscation" ] || die "找不到 ensia 源码（--src <含 obfuscation/ 的目录>）"
[ -n "$SYSROOT" ] && [ -d "$SYSROOT/usr/include" ] || die "找不到 sysroot（--sysroot）"

# 编译器
if [ -z "$CLANG" ]; then
  for c in clang++-21 clang-21 clang++; do
    command -v "$c" >/dev/null 2>&1 && { CLANG=$(command -v "$c"); break; }
  done
fi
[ -n "$CLANG" ] || die "没找到 clang（装 clang-21）"
log "clang: $($CLANG --version | head -1)"
log "src  : $SRC"
log "sys  : $SYSROOT"

# LLVM 头文件目录
INC=""
for c in /usr/lib/llvm-21/include /usr/include/llvm-21 /opt/llvm-21/include "$HERE/../llvm-21/include"; do
  [ -f "$c/llvm/Passes/PassBuilder.h" ] && { INC=$c; break; }
done
[ -n "$INC" ] || die "找不到 LLVM 21 头文件（装 llvm-21-dev，或 --inc 指向 llvm/include）"
log "llvm : $INC"

TARGET="aarch64-linux-android$API"
BUILD=$(mktemp -d)
trap 'rm -rf "$BUILD"' EXIT

CFLAGS=(-fPIC -O2 -std=c++17 -fno-rtti -fexceptions
        "--target=$TARGET" "--sysroot=$SYSROOT"
        -I"$INC" -I"$SRC" -I"$SRC/obfuscation" -I"$SRC/obfuscation/include"
        -DLLVM_NEXT=1 "-DGIT_COMMIT_HASH=\"android-cross\"")
# 注：-fno-exceptions 与 LLVM 默认配置一致；若某个文件报错就去掉它

log "编译 $(ls "$SRC"/obfuscation/*.cpp | wc -l) 个源文件（-j$JOBS）"
OBJS=()
i=0
for f in "$SRC"/obfuscation/*.cpp; do
  o="$BUILD/$(basename "${f%.cpp}").o"
  "$CLANG" "${CFLAGS[@]}" -c "$f" -o "$o" &
  OBJS+=("$o")
  i=$((i+1))
  if [ $((i % JOBS)) -eq 0 ]; then wait; fi
done
wait

log "链接（允许未定义符号，由宿主 clang 提供 LLVM 运行时）"
"$CLANG" "--target=$TARGET" "--sysroot=$SYSROOT" \
  -shared -fPIC -Wl,-soname,libEnsia.so \
  -o "$OUT" "${OBJS[@]}" \
  -static-libstdc++

[ -f "$OUT" ] || die "链接失败"
log "产物: $OUT ($(du -h "$OUT" | cut -f1))"

if command -v readelf >/dev/null; then
  readelf -h "$OUT" | awk -F: '/Machine|Type/{gsub(/^ +/,"",$2); print "   "$1":"$2}'
  N=$(readelf --dyn-syms -W "$OUT" 2>/dev/null | grep -c llvmGetPassPluginInfo || true)
  [ "${N:-0}" -gt 0 ] && log "✔ 导出 llvmGetPassPluginInfo" || log "⚠ 没看到 llvmGetPassPluginInfo，检查导出设置"
fi

cat <<EOF

下一步（放进 NDK）：
  PRE=<ndk>/toolchains/llvm/prebuilt/linux-arm        # TUSI 包的目录名
  cp "$OUT" \$PRE/ensia/lib/libEnsia.so
  date > \$PRE/ensia/lib/.plugin-capable
  # 之后 ENSIA=1 编译即自动注入 -fpass-plugin

注意：
  * 目标 clang 必须与这套 LLVM 头文件同版本（TUSI clang = LLVM 21.0.0，apt 的 21.x 兼容）。
  * 如果加载时崩在 IR/字符串，多为「插件与 clang 的 LLVM 构建配置不一致」，
    优先用同 minor 版本的头文件。
EOF
