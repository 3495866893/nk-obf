#!/data/data/com.termux/files/usr/bin/bash
# =============================================================================
# termux-build-plugin.sh —— 在安卓手机上（Termux）编译 ensia 插件
# -----------------------------------------------------------------------------
# 用途：不想等电脑/Actions 时，用 Termux 自带的 LLVM 当「插件宿主」，
#       本地编 libEnsia.so（几分钟），再用同一套 clang 编你的原生代码。
#
# 前提：
#   * Termux（F-Droid 版），pkg install llvm cmake ninja git
#   * Termux 的 llvm 必须是 21.x（llvm-config --version 查看），否则插件 ABI 不匹配
#   * 内存 ≥ 4 GB（编插件本身不吃内存；别把它和「编 clang」搞混）
#
# 产物：<kit>/lib/libEnsia.so（只能被 Termux 的 clang 加载）
#
# 之后编译你的代码（交叉到 Android arm64，用 NDK 的 sysroot）：
#   <kit>/bin/ensia-clang --abi arm64-v8a --api 26 --preset max \
#       -O2 -shared -fPIC -o libnative.so your.c
# =============================================================================
set -euo pipefail

KIT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
PRE=$(cd -- "$KIT/.." && pwd)
SYSROOT="$PRE/sysroot"

say() { printf '\033[1m[ensia-termux]\033[0m %s\n' "$*"; }
die() { printf '[ensia-termux] 错误: %s\n' "$*" >&2; exit 1; }

say "kit : $KIT"
say "sysroot: $SYSROOT"

# --- 1. 依赖 ---------------------------------------------------------------
command -v pkg >/dev/null || die "这不是 Termux 环境（找不到 pkg）"
for t in clang cmake ninja llvm-config; do
  command -v "$t" >/dev/null || { say "安装缺失依赖：$t"; pkg install -y llvm cmake ninja git clang; break; }
done

LLVM_VER=$(llvm-config --version 2>/dev/null || echo "")
say "Termux LLVM: ${LLVM_VER:-未安装}"
case "$LLVM_VER" in
  21.*|22.*|23.*) : ;;
  "") die "没装 llvm：pkg install llvm" ;;
  *)  say "⚠ 版本是 $LLVM_VER，ensia 官方支持 21/22/23；继续尝试，失败就 pkg upgrade" ;;
esac

[ -d "$SYSROOT" ] || say "⚠ 找不到 $SYSROOT（ensia-clang 交叉编译会失败；仅编插件不影响）"

# --- 2. 编插件 -------------------------------------------------------------
LLVM_CMAKE=$(llvm-config --cmakedir 2>/dev/null || true)
[ -n "$LLVM_CMAKE" ] || die "llvm-config --cmakedir 为空（Termux 的 llvm 包不全？）"
say "LLVM cmake: $LLVM_CMAKE"

say "开始编译 libEnsia.so（native，-j2）"
"$KIT/bin/build-plugin.sh" --llvm-dir "$LLVM_CMAKE" --mode native --jobs 2 --clean

# --- 3. 自检 ---------------------------------------------------------------
SO="$KIT/lib/libEnsia.so"
[ -f "$SO" ] || die "编译结束但没找到 $SO"
say "✔ 插件: $SO ($(du -h "$SO" | cut -f1))"

# 插件只对 Termux 的 clang 有效；NDK 里的 clang-21 是静态版，加载不了
cat <<EOF

下一步（在 Termux 里交叉编译你的代码）：
  $KIT/bin/ensia-clang --abi arm64-v8a --api 26 --preset max \\
      -O2 -shared -fPIC -o libyour.so your.c

注意：
  * 这个 libEnsia.so 只能被 Termux 的 clang 加载（同一份 LLVM 构建）。
  * AIDE 不能直接调用 Termux 的可执行文件（SELinux/应用沙箱），
    所以「编译」在 Termux 做，「打包 APK」在 AIDE 做（把编好的 .so 放进工程）。
  * 想让 AIDE 内部直接混淆（ndk-build 里就带 -fpass-plugin），
    仍然需要电脑/Actions 产出的 dropin（可加载插件的 NDK clang）。
EOF
