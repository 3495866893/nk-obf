/* Ensia 集成自检样本：同时覆盖常量、字符串、循环、分支、算术混合 */
#include <stdio.h>
#include <string.h>

const char *ensia_secret_token = "ENSIA_SECRET_TOKEN_12345";
static const unsigned int ENSIA_MAGIC = 0x9E3779B9u;

static int mix(int a, int b) {
  return ((a ^ b) + (a << 3)) - (b >> 2);
}

int ensia_calc(int x) {
  int s = 0;
  for (int i = 0; i < 16; i++) {
    s += mix(x + i, i * 7) ^ (int)ENSIA_MAGIC;
    if ((s & 1) == 0) {
      s += 3;
    } else {
      s -= 5;
    }
  }
  return s;
}

int ensia_check(const char *s) {
  if (s == NULL) return -1;
  return strcmp(s, ensia_secret_token) == 0 ? 0 : 1;
}

int main(void) {
  printf("%s %d\n", ensia_secret_token, ensia_calc(42));
  return ensia_check(ensia_secret_token);
}
